"""
Run baseline evaluation
Get initial metrics for comparison
"""
from src.data_ingestion import ArXivIngester
from src.rag_pipeline import RAGPipeline
from src.evaluation import RAGEvaluator

def main():
    print("Running Baseline Evaluation...")
    
    # Setup
    ingester = ArXivIngester()
    papers = ingester.load_papers()
    
    if len(papers) < 20:
        print(f"Only {len(papers)} papers found. Fetching 30 papers...")
        papers = ingester.fetch_papers(max_results=30)
        ingester.save_papers(papers)
    
    if len(papers) < 10:
        print("Error: Need at least 10 papers")
        return
    
    print(f"Using {len(papers)} papers")
    
    # Initialize RAG
    print("\nInitializing RAG pipeline...")
    rag = RAGPipeline()
    
    # Chunk and add papers
    print("Chunking papers and generating embeddings...")
    all_chunks = []
    for i, paper in enumerate(papers):
        chunks = ingester.chunk_paper(paper)
        all_chunks.extend(chunks)
        if (i + 1) % 10 == 0:
            print(f"  Processed {i + 1}/{len(papers)} papers...")
    
    print(f"Adding {len(all_chunks)} chunks to vector database...")
    rag.add_documents(all_chunks)
    
    # Test queries
    test_queries = [
        "What are transformer architectures?",
        "How do neural networks learn?",
        "What is machine learning?",
        "What are the applications of computer vision?",
        "What is the difference between RNN and LSTM?",
        "How does reinforcement learning work?",
        "What are the main approaches to natural language processing?",
        "How do large language models work?",
        "What is deep learning?",
        "What are generative adversarial networks?"
    ]
    
    print(f"\nEvaluating with {len(test_queries)} queries...")
    
    # Evaluate
    evaluator = RAGEvaluator(rag)
    
    print("Creating evaluation dataset...")
    eval_dataset = evaluator.create_evaluation_dataset(test_queries)
    
    print("Running RAGAS evaluation...")
    try:
        metrics = evaluator.evaluate_rag(eval_dataset)
        
        print("\n" + "="*60)
        print("Baseline RAG Metrics:")
        print("="*60)
        for metric, value in metrics.items():
            if metric != 'error':
                print(f"{metric:20s}: {value:.3f}")
        
        # Retrieval stats
        stats = evaluator.get_retrieval_stats(test_queries)
        print("\n" + "="*60)
        print("Retrieval Statistics:")
        print("="*60)
        for stat, value in stats.items():
            if isinstance(value, float):
                print(f"{stat:20s}: {value:.2f}")
            else:
                print(f"{stat:20s}: {value}")
        
        print("\n✅ Baseline evaluation complete!")
        print("\nSave these metrics for comparison with improved methods.")
        
    except Exception as e:
        print(f"\n⚠️  Evaluation error: {e}")
        print("This is normal if RAGAS dependencies are not fully set up.")
        print("The retrieval pipeline still works - you can test queries manually.")

if __name__ == "__main__":
    main()

