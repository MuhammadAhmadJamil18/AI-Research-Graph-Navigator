"""
Test script for entity extractor
Run this to verify NLP-based entity extraction works
"""
from src.entity_extractor import EntityExtractor
from src.data_ingestion import ArXivIngester

def main():
    print("Testing Entity Extractor...")
    
    # Load a paper
    ingester = ArXivIngester()
    papers = ingester.load_papers()
    
    if not papers:
        print("No papers found. Fetching 5 papers...")
        papers = ingester.fetch_papers(max_results=5)
        ingester.save_papers(papers)
    
    if not papers:
        print("Error: Could not fetch papers")
        return
    
    # Test entity extraction
    print(f"\nTesting with paper: {papers[0]['title'][:50]}...")
    
    extractor = EntityExtractor(use_spacy=False)  # Disable spaCy if not installed
    paper = papers[0]
    
    entities = extractor.extract_entities(paper)
    
    print("\n" + "="*60)
    print("Extracted Entities:")
    print("="*60)
    
    for entity_type, entity_list in entities.items():
        print(f"\n{entity_type.upper()}: {len(entity_list)} entities")
        for entity, confidence in entity_list[:5]:  # Show top 5
            print(f"  - {entity} (confidence: {confidence:.3f})")
    
    # Filter by confidence
    print("\n" + "="*60)
    print("Filtered by confidence >= 0.5:")
    print("="*60)
    
    filtered = extractor.filter_by_confidence(entities, min_confidence=0.5)
    for entity_type, entity_list in filtered.items():
        if entity_list:
            print(f"\n{entity_type.upper()}: {len(entity_list)} entities")
            for entity, confidence in entity_list[:3]:
                print(f"  - {entity} (confidence: {confidence:.3f})")
    
    print("\n[SUCCESS] Entity extraction test complete!")

if __name__ == "__main__":
    main()

