"""
Test script for improved graph builder
Run this to verify improved graph construction works
"""
from src.improved_graph_builder import ImprovedKnowledgeGraphBuilder
from src.data_ingestion import ArXivIngester

def main():
    print("Testing Improved Graph Builder...")
    
    # Load papers
    ingester = ArXivIngester()
    papers = ingester.load_papers()
    
    if not papers or len(papers) < 10:
        print("Fetching 20 papers...")
        papers = ingester.fetch_papers(max_results=20)
        ingester.save_papers(papers)
    
    if not papers:
        print("Error: Could not fetch papers")
        return
    
    print(f"Building graph with {len(papers)} papers...")
    
    # Build graph with improved method
    builder = ImprovedKnowledgeGraphBuilder(
        min_entity_confidence=0.5,
        min_edge_weight=0.3,
        use_pruning=True
    )
    
    builder.build_graph(papers)
    stats = builder.get_statistics()
    
    print("\n" + "="*60)
    print("Graph Statistics:")
    print("="*60)
    print(f"Total Nodes: {stats['nodes']}")
    print(f"Total Edges: {stats['edges']}")
    print(f"Connected Components: {stats['num_components']}")
    print(f"Average Degree: {stats['avg_degree']:.2f}")
    print(f"\nNode Types:")
    for node_type, count in stats['node_types'].items():
        print(f"  - {node_type}: {count}")
    
    # Test neighbor retrieval
    if papers:
        paper_id = papers[0]['id']
        neighbors = builder.get_paper_neighbors(paper_id)
        print(f"\nNeighbors of first paper ({len(neighbors)}):")
        for neighbor in neighbors[:5]:
            print(f"  - {neighbor['type']}: {neighbor['data'].get('name', neighbor['id'])} "
                  f"(confidence: {neighbor.get('confidence', 0):.3f})")
    
    # Save graph
    builder.save_graph("data/improved_knowledge_graph.json")
    print("\n[SUCCESS] Graph saved to data/improved_knowledge_graph.json")
    print("[SUCCESS] Improved graph builder test complete!")

if __name__ == "__main__":
    main()

