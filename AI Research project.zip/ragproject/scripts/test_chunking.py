"""
Test script for chunking strategies
Compare fixed vs semantic chunking
"""
from src.improved_chunking import SemanticChunker, FixedChunker
from src.data_ingestion import ArXivIngester

def main():
    print("Testing Chunking Strategies...")
    
    # Load a paper
    ingester = ArXivIngester()
    papers = ingester.load_papers()
    
    if not papers:
        print("Fetching 1 paper...")
        papers = ingester.fetch_papers(max_results=1)
        ingester.save_papers(papers)
    
    if not papers:
        print("Error: Could not fetch papers")
        return
    
    paper = papers[0]
    print(f"\nTesting with paper: {paper['title'][:50]}...")
    
    # Test fixed chunking
    print("\n" + "="*60)
    print("Fixed Chunking:")
    print("="*60)
    fixed_chunker = FixedChunker(chunk_size=500, overlap=50)
    fixed_chunks = fixed_chunker.chunk(paper)
    print(f"Number of chunks: {len(fixed_chunks)}")
    print(f"Average chunk length: {sum(len(c['chunk_text']) for c in fixed_chunks) / len(fixed_chunks):.0f} chars")
    print(f"\nFirst chunk preview:")
    print(f"{fixed_chunks[0]['chunk_text'][:200]}...")
    
    # Test semantic chunking
    print("\n" + "="*60)
    print("Semantic Chunking:")
    print("="*60)
    semantic_chunker = SemanticChunker(chunk_size=500, overlap=50, respect_sections=True)
    semantic_chunks = semantic_chunker.chunk(paper)
    print(f"Number of chunks: {len(semantic_chunks)}")
    print(f"Average chunk length: {sum(len(c['chunk_text']) for c in semantic_chunks) / len(semantic_chunks):.0f} chars")
    
    # Show sections found
    sections = set(c.get('section', 'Unknown') for c in semantic_chunks)
    print(f"Sections identified: {', '.join(sections)}")
    
    print(f"\nFirst chunk preview:")
    print(f"{semantic_chunks[0]['chunk_text'][:200]}...")
    
    # Compare
    print("\n" + "="*60)
    print("Comparison:")
    print("="*60)
    print(f"Fixed chunks: {len(fixed_chunks)}")
    print(f"Semantic chunks: {len(semantic_chunks)}")
    print(f"Difference: {len(semantic_chunks) - len(fixed_chunks)} chunks")
    
    print("\n[SUCCESS] Chunking test complete!")

if __name__ == "__main__":
    main()

