"""
Advanced Graph Analysis
Includes PageRank, community detection, and centrality measures
"""
import networkx as nx
from typing import Dict, List
import numpy as np
from collections import defaultdict


class GraphAnalyzer:
    """Advanced graph analysis for knowledge graphs"""
    
    def __init__(self, graph):
        """
        Initialize graph analyzer
        
        Args:
            graph: NetworkX graph object
        """
        self.graph = graph
    
    def calculate_pagerank(self, damping: float = 0.85) -> Dict[str, float]:
        """
        Calculate PageRank for nodes
        
        Args:
            damping: Damping factor for PageRank
            
        Returns:
            Dictionary of node_id -> PageRank score
        """
        if not self.graph:
            return {}
        
        # Convert to directed graph if needed
        if not self.graph.is_directed():
            G = self.graph.to_directed()
        else:
            G = self.graph
        
        pagerank = nx.pagerank(G, alpha=damping)
        return pagerank
    
    def find_communities(self, algorithm: str = "louvain") -> Dict[str, int]:
        """
        Find communities in the graph
        
        Args:
            algorithm: Community detection algorithm ('louvain' or 'greedy')
            
        Returns:
            Dictionary of node_id -> community_id
        """
        if not self.graph:
            return {}
        
        # Convert to undirected for community detection
        G = self.graph.to_undirected() if self.graph.is_directed() else self.graph
        
        if algorithm == "louvain":
            try:
                import community as community_louvain
                communities = community_louvain.best_partition(G)
            except ImportError:
                # Fallback to greedy modularity
                communities = self._greedy_modularity_communities(G)
        else:
            communities = self._greedy_modularity_communities(G)
        
        return communities
    
    def _greedy_modularity_communities(self, G):
        """Greedy modularity maximization for community detection"""
        communities_generator = nx.community.greedy_modularity_communities(G)
        communities = {}
        for i, community in enumerate(communities_generator):
            for node in community:
                communities[node] = i
        return communities
    
    def calculate_centrality_measures(self) -> Dict[str, Dict]:
        """
        Calculate various centrality measures
        
        Returns:
            Dictionary with centrality measures for each node
        """
        if not self.graph:
            return {}
        
        G = self.graph.to_undirected() if self.graph.is_directed() else self.graph
        
        centralities = {}
        
        # Degree centrality
        degree_centrality = nx.degree_centrality(G)
        
        # Betweenness centrality
        betweenness_centrality = nx.betweenness_centrality(G)
        
        # Closeness centrality
        closeness_centrality = nx.closeness_centrality(G)
        
        # Eigenvector centrality
        try:
            eigenvector_centrality = nx.eigenvector_centrality(G, max_iter=1000)
        except:
            eigenvector_centrality = {}
        
        # Combine for each node
        for node in G.nodes():
            centralities[node] = {
                "degree": degree_centrality.get(node, 0),
                "betweenness": betweenness_centrality.get(node, 0),
                "closeness": closeness_centrality.get(node, 0),
                "eigenvector": eigenvector_centrality.get(node, 0)
            }
        
        return centralities
    
    def identify_key_papers(self, top_k: int = 10) -> List[Dict]:
        """
        Identify key papers using multiple metrics
        
        Args:
            top_k: Number of top papers to return
            
        Returns:
            List of key papers with scores
        """
        if not self.graph:
            return []
        
        # Get paper nodes
        paper_nodes = [
            node for node, data in self.graph.nodes(data=True)
            if data.get('node_type') == 'paper'
        ]
        
        if not paper_nodes:
            return []
        
        # Calculate PageRank
        pagerank = self.calculate_pagerank()
        
        # Calculate centralities
        centralities = self.calculate_centrality_measures()
        
        # Score papers
        paper_scores = []
        for paper_id in paper_nodes:
            node_data = self.graph.nodes[paper_id]
            
            score = {
                "paper_id": paper_id,
                "title": node_data.get('title', 'Unknown'),
                "pagerank": pagerank.get(paper_id, 0),
                "degree_centrality": centralities.get(paper_id, {}).get('degree', 0),
                "betweenness_centrality": centralities.get(paper_id, {}).get('betweenness', 0),
                "closeness_centrality": centralities.get(paper_id, {}).get('closeness', 0),
                "combined_score": 0
            }
            
            # Combined score (weighted average)
            score["combined_score"] = (
                0.4 * score["pagerank"] +
                0.3 * score["degree_centrality"] +
                0.2 * score["betweenness_centrality"] +
                0.1 * score["closeness_centrality"]
            )
            
            paper_scores.append(score)
        
        # Sort by combined score
        paper_scores.sort(key=lambda x: x["combined_score"], reverse=True)
        
        return paper_scores[:top_k]
    
    def analyze_graph_structure(self) -> Dict:
        """
        Analyze overall graph structure
        
        Returns:
            Dictionary with graph statistics
        """
        if not self.graph:
            return {}
        
        G = self.graph.to_undirected() if self.graph.is_directed() else self.graph
        
        analysis = {
            "num_nodes": self.graph.number_of_nodes(),
            "num_edges": self.graph.number_of_edges(),
            "density": nx.density(G),
            "average_clustering": nx.average_clustering(G),
            "is_connected": nx.is_connected(G),
            "num_connected_components": nx.number_connected_components(G),
            "average_degree": sum(dict(G.degree()).values()) / G.number_of_nodes() if G.number_of_nodes() > 0 else 0
        }
        
        # Node type distribution
        node_types = defaultdict(int)
        for node, data in self.graph.nodes(data=True):
            node_type = data.get('node_type', 'unknown')
            node_types[node_type] += 1
        analysis["node_type_distribution"] = dict(node_types)
        
        # Calculate diameter if connected
        if analysis["is_connected"]:
            try:
                analysis["diameter"] = nx.diameter(G)
                analysis["average_path_length"] = nx.average_shortest_path_length(G)
            except:
                analysis["diameter"] = None
                analysis["average_path_length"] = None
        
        return analysis
    
    def find_influential_authors(self, top_k: int = 10) -> List[Dict]:
        """
        Find influential authors based on graph connections
        
        Args:
            top_k: Number of top authors to return
            
        Returns:
            List of influential authors with metrics
        """
        if not self.graph:
            return []
        
        # Get author nodes
        author_nodes = [
            node for node, data in self.graph.nodes(data=True)
            if data.get('node_type') == 'author'
        ]
        
        if not author_nodes:
            return []
        
        # Calculate metrics for authors
        author_scores = []
        for author_id in author_nodes:
            node_data = self.graph.nodes[author_id]
            
            # Count papers authored
            papers_authored = len([
                neighbor for neighbor in self.graph.neighbors(author_id)
                if self.graph.nodes[neighbor].get('node_type') == 'paper'
            ])
            
            # Count co-authors (authors connected through papers)
            co_authors = set()
            for paper in self.graph.neighbors(author_id):
                if self.graph.nodes[paper].get('node_type') == 'paper':
                    for neighbor in self.graph.neighbors(paper):
                        if (self.graph.nodes[neighbor].get('node_type') == 'author' and
                            neighbor != author_id):
                            co_authors.add(neighbor)
            
            score = {
                "author_id": author_id,
                "name": node_data.get('name', 'Unknown'),
                "papers_count": papers_authored,
                "co_authors_count": len(co_authors),
                "influence_score": papers_authored * (1 + len(co_authors) * 0.1)
            }
            
            author_scores.append(score)
        
        # Sort by influence score
        author_scores.sort(key=lambda x: x["influence_score"], reverse=True)
        
        return author_scores[:top_k]

