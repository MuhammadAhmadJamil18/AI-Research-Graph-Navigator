"""
Knowledge Graph Builder for research papers
"""

import json
import os
import re
from typing import Dict, List

import networkx as nx


class KnowledgeGraphBuilder:
    """Builds knowledge graph from research papers"""

    def __init__(self) -> None:
        """
        Initialize knowledge graph builder.

        Creates an empty NetworkX MultiDiGraph for storing papers,
        authors, concepts, and their relationships.

        Returns:
            None
        """
        self.graph = nx.MultiDiGraph()

    def extract_entities(self, paper: Dict) -> Dict[str, List[str]]:
        """
        Extract entities from a research paper.

        Extracts authors, categories, keywords, and concepts from a paper
        dictionary using simple pattern matching and keyword extraction.

        Args:
            paper: Paper dictionary with keys:
                - 'authors': List of author names
                - 'categories': List of ArXiv categories
                - 'summary': Paper abstract/text for keyword/concept extraction

        Returns:
            Dictionary with entity types as keys and lists of entities as values:
                - 'authors': List of author names
                - 'categories': List of categories
                - 'keywords': List of extracted keywords
                - 'concepts': List of AI/ML concepts found

        Example:
            >>> paper = {
            ...     'authors': ['John Doe'],
            ...     'categories': ['cs.AI'],
            ...     'summary': 'This paper discusses transformers...'
            ... }
            >>> entities = builder.extract_entities(paper)
            >>> print(entities['keywords'])
        """
        entities = {
            "authors": paper.get("authors", []),
            "categories": paper.get("categories", []),
            "keywords": self._extract_keywords(paper.get("summary", "")),
            "concepts": self._extract_concepts(paper.get("summary", "")),
        }
        return entities

    def _extract_keywords(self, text: str) -> List[str]:
        """
        Extract potential keywords from text using pattern matching.

        Finds capitalized words and phrases that are likely to be important
        technical terms or concepts.

        Args:
            text: Text content to extract keywords from

        Returns:
            List of unique keywords (top 10, filtered for common words)
        """
        # Simple keyword extraction (can be enhanced with NLP)
        words = re.findall(r"\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\b", text)
        # Filter common words and get unique
        common_words = {"The", "This", "We", "Our", "In", "On", "At", "For", "With"}
        keywords = [w for w in words if w not in common_words and len(w) > 3]
        return list(set(keywords[:10]))  # Top 10 unique keywords

    def _extract_concepts(self, text: str) -> List[str]:
        """Extract AI/ML concepts from text"""
        # Common AI/ML concepts to look for
        concepts = [
            "machine learning",
            "deep learning",
            "neural network",
            "transformer",
            "reinforcement learning",
            "natural language processing",
            "computer vision",
            "generative adversarial network",
            "large language model",
            "attention mechanism",
            "transfer learning",
            "few-shot learning",
            "zero-shot learning",
            "fine-tuning",
        ]

        found_concepts = []
        text_lower = text.lower()
        for concept in concepts:
            if concept in text_lower:
                found_concepts.append(concept.title())

        return list(set(found_concepts))

    def build_graph(self, papers: List[Dict]) -> None:
        """
        Build knowledge graph from research papers.

        Extracts entities (authors, categories, concepts, keywords) from papers
        and creates a NetworkX graph with nodes for papers and entities, and edges
        representing relationships between them.

        Args:
            papers: List of paper dictionaries with required keys:
                - 'id': Unique paper identifier
                - 'title': Paper title
                - 'summary': Paper abstract/summary
                - 'authors': List of author names
                - 'categories': List of ArXiv categories

        Returns:
            None (modifies self.graph in place)

        Raises:
            KeyError: If required paper keys are missing
            ValueError: If papers list is empty

        Example:
            >>> builder = KnowledgeGraphBuilder()
            >>> papers = [{
            ...     'id': '123',
            ...     'title': 'AI Research',
            ...     'summary': 'About AI...',
            ...     'authors': ['John Doe'],
            ...     'categories': ['cs.AI']
            ... }]
            >>> builder.build_graph(papers)
            >>> print(builder.graph.number_of_nodes())
        """
        print("Building knowledge graph...")

        # Add paper nodes
        for paper in papers:
            paper_id = paper["id"]
            self.graph.add_node(
                paper_id,
                node_type="paper",
                title=paper.get("title", ""),
                summary=paper.get("summary", "")[:200],  # Truncate for visualization
                published=paper.get("published", ""),
                categories=paper.get("categories", []),
            )

            # Extract entities
            entities = self.extract_entities(paper)

            # Add author nodes and edges
            for author in entities.get("authors", []):
                author_id = f"author_{author.replace(' ', '_')}"
                if not self.graph.has_node(author_id):
                    self.graph.add_node(author_id, node_type="author", name=author)
                self.graph.add_edge(paper_id, author_id, relation="authored_by")
                self.graph.add_edge(author_id, paper_id, relation="authored")

            # Add category nodes and edges
            for category in entities.get("categories", []):
                cat_id = f"category_{category}"
                if not self.graph.has_node(cat_id):
                    self.graph.add_node(cat_id, node_type="category", name=category)
                self.graph.add_edge(paper_id, cat_id, relation="belongs_to")

            # Add concept nodes and edges
            for concept in entities.get("concepts", []):
                concept_id = f"concept_{concept.replace(' ', '_')}"
                if not self.graph.has_node(concept_id):
                    self.graph.add_node(concept_id, node_type="concept", name=concept)
                self.graph.add_edge(paper_id, concept_id, relation="discusses")
                self.graph.add_edge(concept_id, paper_id, relation="discussed_in")

            # Add keyword nodes and edges
            for keyword in entities.get("keywords", [])[:5]:  # Top 5 keywords
                keyword_id = f"keyword_{keyword.replace(' ', '_')}"
                if not self.graph.has_node(keyword_id):
                    self.graph.add_node(keyword_id, node_type="keyword", name=keyword)
                self.graph.add_edge(paper_id, keyword_id, relation="contains")

        # Add similarity edges between papers (based on shared authors/concepts)
        self._add_similarity_edges(papers)

        print(
            f"Graph built: {self.graph.number_of_nodes()} nodes, {self.graph.number_of_edges()} edges"
        )

    def _add_similarity_edges(self, papers: List[Dict]):
        """Add edges between similar papers"""
        paper_entities = {}

        # Build entity sets for each paper
        for paper in papers:
            paper_id = paper["id"]
            entities = self.extract_entities(paper)
            paper_entities[paper_id] = {
                "authors": set(entities.get("authors", [])),
                "concepts": set(entities.get("concepts", [])),
            }

        # Add edges for papers with shared entities
        paper_ids = list(paper_entities.keys())
        for i, paper_id1 in enumerate(paper_ids):
            for paper_id2 in paper_ids[i + 1 :]:
                entities1 = paper_entities[paper_id1]
                entities2 = paper_entities[paper_id2]

                # Check for shared authors
                shared_authors = entities1["authors"] & entities2["authors"]
                if shared_authors:
                    self.graph.add_edge(
                        paper_id1, paper_id2, relation="similar_author", weight=len(shared_authors)
                    )

                # Check for shared concepts
                shared_concepts = entities1["concepts"] & entities2["concepts"]
                if shared_concepts:
                    self.graph.add_edge(
                        paper_id1,
                        paper_id2,
                        relation="similar_concept",
                        weight=len(shared_concepts),
                    )

    def get_paper_neighbors(self, paper_id: str, relation_type: str = None) -> List[Dict]:
        """
        Get neighboring nodes of a paper

        Args:
            paper_id: Paper ID
            relation_type: Filter by relation type (optional)

        Returns:
            List of neighbor dictionaries
        """
        neighbors = []
        if not self.graph.has_node(paper_id):
            return neighbors

        for neighbor_id in self.graph.neighbors(paper_id):
            neighbor_data = self.graph.nodes[neighbor_id]
            edges = self.graph[paper_id][neighbor_id]

            for edge_key, edge_data in edges.items():
                if relation_type is None or edge_data.get("relation") == relation_type:
                    neighbors.append(
                        {
                            "id": neighbor_id,
                            "type": neighbor_data.get("node_type", "unknown"),
                            "data": neighbor_data,
                            "relation": edge_data.get("relation", "unknown"),
                        }
                    )
                    break  # Only add once per neighbor

        return neighbors

    def find_path(self, source_id: str, target_id: str, max_depth: int = 3) -> List[List[str]]:
        """
        Find paths between two nodes

        Args:
            source_id: Source node ID
            target_id: Target node ID
            max_depth: Maximum path length

        Returns:
            List of paths (each path is a list of node IDs)
        """
        try:
            paths = list(
                nx.all_simple_paths(
                    self.graph.to_undirected(), source_id, target_id, cutoff=max_depth
                )
            )
            return paths[:10]  # Limit to 10 paths
        except Exception:
            return []

    def get_subgraph(self, paper_ids: List[str], depth: int = 1) -> nx.MultiDiGraph:
        """
        Get subgraph around specific papers

        Args:
            paper_ids: List of paper IDs
            depth: Depth of neighbors to include

        Returns:
            Subgraph
        """
        nodes_to_include = set(paper_ids)

        # Add neighbors up to specified depth
        current_nodes = set(paper_ids)
        for _ in range(depth):
            next_nodes = set()
            for node in current_nodes:
                if self.graph.has_node(node):
                    next_nodes.update(self.graph.neighbors(node))
            nodes_to_include.update(next_nodes)
            current_nodes = next_nodes

        return self.graph.subgraph(nodes_to_include)

    def save_graph(self, filepath: str = "data/knowledge_graph.json"):
        """Save graph to JSON file"""
        os.makedirs(os.path.dirname(filepath), exist_ok=True)

        graph_data = {
            "nodes": [{"id": node_id, **data} for node_id, data in self.graph.nodes(data=True)],
            "edges": [
                {
                    "source": source,
                    "target": target,
                    "relation": data.get("relation", "unknown"),
                    "weight": data.get("weight", 1),
                }
                for source, target, data in self.graph.edges(data=True)
            ],
        }

        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(graph_data, f, indent=2, ensure_ascii=False)

        print(f"Graph saved to {filepath}")

    def load_graph(self, filepath: str = "data/knowledge_graph.json"):
        """Load graph from JSON file"""
        if not os.path.exists(filepath):
            return False

        with open(filepath, "r", encoding="utf-8") as f:
            graph_data = json.load(f)

        self.graph = nx.MultiDiGraph()

        # Add nodes
        for node in graph_data.get("nodes", []):
            node_id = node.pop("id")
            self.graph.add_node(node_id, **node)

        # Add edges
        for edge in graph_data.get("edges", []):
            self.graph.add_edge(
                edge["source"],
                edge["target"],
                relation=edge.get("relation", "unknown"),
                weight=edge.get("weight", 1),
            )

        print(f"Graph loaded from {filepath}")
        return True

    def get_statistics(self) -> Dict:
        """Get graph statistics"""
        return {
            "nodes": self.graph.number_of_nodes(),
            "edges": self.graph.number_of_edges(),
            "papers": len(
                [n for n, d in self.graph.nodes(data=True) if d.get("node_type") == "paper"]
            ),
            "authors": len(
                [n for n, d in self.graph.nodes(data=True) if d.get("node_type") == "author"]
            ),
            "concepts": len(
                [n for n, d in self.graph.nodes(data=True) if d.get("node_type") == "concept"]
            ),
            "is_connected": nx.is_weakly_connected(self.graph),
        }
