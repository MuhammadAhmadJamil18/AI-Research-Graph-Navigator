"""
Experimental Results Tracking and Analysis
"""
import json
import os
from typing import Dict, List, Optional
from datetime import datetime
import pandas as pd
import numpy as np


class ExperimentTracker:
    """
    Track and analyze experimental results
    """
    
    def __init__(self, results_dir: str = "results"):
        """
        Initialize experiment tracker
        
        Args:
            results_dir: Directory to store results
        """
        self.results_dir = results_dir
        os.makedirs(results_dir, exist_ok=True)
        
    def log_experiment(
        self,
        experiment_name: str,
        config: Dict,
        results: Dict,
        metadata: Optional[Dict] = None
    ):
        """
        Log an experiment with configuration and results
        
        Args:
            experiment_name: Name of the experiment
            config: Configuration parameters
            results: Experimental results
            metadata: Additional metadata
        """
        experiment = {
            "experiment_name": experiment_name,
            "timestamp": datetime.now().isoformat(),
            "config": config,
            "results": results,
            "metadata": metadata or {}
        }
        
        # Save experiment
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{experiment_name}_{timestamp}.json"
        filepath = os.path.join(self.results_dir, filename)
        
        with open(filepath, 'w') as f:
            json.dump(experiment, f, indent=2)
        
        print(f"Experiment logged: {filepath}")
        return filepath
    
    def load_experiment(self, filename: str) -> Dict:
        """
        Load an experiment from file
        
        Args:
            filename: Name of experiment file
            
        Returns:
            Experiment dictionary
        """
        filepath = os.path.join(self.results_dir, filename)
        if os.path.exists(filepath):
            with open(filepath, 'r') as f:
                return json.load(f)
        return {}
    
    def list_experiments(self, experiment_name: Optional[str] = None) -> List[str]:
        """
        List all experiments
        
        Args:
            experiment_name: Filter by experiment name (optional)
            
        Returns:
            List of experiment filenames
        """
        files = [f for f in os.listdir(self.results_dir) if f.endswith('.json')]
        if experiment_name:
            files = [f for f in files if f.startswith(experiment_name)]
        return sorted(files, reverse=True)
    
    def compare_experiments(
        self,
        experiment_files: List[str],
        metrics: List[str]
    ) -> pd.DataFrame:
        """
        Compare multiple experiments
        
        Args:
            experiment_files: List of experiment filenames
            metrics: List of metrics to compare
            
        Returns:
            Comparison DataFrame
        """
        comparison_data = []
        
        for filename in experiment_files:
            experiment = self.load_experiment(filename)
            if not experiment:
                continue
            
            row = {
                "experiment": experiment.get("experiment_name", ""),
                "timestamp": experiment.get("timestamp", "")
            }
            
            # Extract metrics from results
            results = experiment.get("results", {})
            for metric in metrics:
                if isinstance(results, dict):
                    # Try different paths for metrics
                    value = (
                        results.get(metric) or
                        results.get("quality_metrics", {}).get(metric) or
                        results.get("metrics", {}).get(metric)
                    )
                    row[metric] = value
            
            comparison_data.append(row)
        
        return pd.DataFrame(comparison_data)
    
    def aggregate_results(
        self,
        experiment_files: List[str],
        metric: str
    ) -> Dict:
        """
        Aggregate results across experiments
        
        Args:
            experiment_files: List of experiment filenames
            metric: Metric to aggregate
            
        Returns:
            Aggregation statistics
        """
        values = []
        
        for filename in experiment_files:
            experiment = self.load_experiment(filename)
            if not experiment:
                continue
            
            results = experiment.get("results", {})
            value = (
                results.get(metric) or
                results.get("quality_metrics", {}).get(metric) or
                results.get("metrics", {}).get(metric)
            )
            
            if value is not None:
                values.append(float(value))
        
        if not values:
            return {}
        
        return {
            "mean": float(np.mean(values)),
            "std": float(np.std(values)),
            "min": float(np.min(values)),
            "max": float(np.max(values)),
            "median": float(np.median(values)),
            "count": len(values)
        }
    
    def export_to_csv(self, experiment_files: List[str], output_file: str):
        """
        Export experiments to CSV
        
        Args:
            experiment_files: List of experiment filenames
            output_file: Output CSV filename
        """
        all_data = []
        
        for filename in experiment_files:
            experiment = self.load_experiment(filename)
            if not experiment:
                continue
            
            # Flatten experiment data
            row = {
                "experiment_name": experiment.get("experiment_name", ""),
                "timestamp": experiment.get("timestamp", "")
            }
            
            # Add config
            config = experiment.get("config", {})
            for key, value in config.items():
                row[f"config_{key}"] = value
            
            # Add results
            results = experiment.get("results", {})
            if isinstance(results, dict):
                for key, value in results.items():
                    if isinstance(value, dict):
                        for subkey, subvalue in value.items():
                            row[f"{key}_{subkey}"] = subvalue
                    else:
                        row[key] = value
            
            all_data.append(row)
        
        df = pd.DataFrame(all_data)
        filepath = os.path.join(self.results_dir, output_file)
        df.to_csv(filepath, index=False)
        print(f"Exported to {filepath}")
