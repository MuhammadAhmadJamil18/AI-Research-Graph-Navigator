"""
Benchmarking and Performance Analysis Module
"""
import time
import json
import os
from typing import List, Dict, Optional
from datetime import datetime
import pandas as pd
import numpy as np
from src.rag_pipeline import RAGPipeline
from src.graph_rag import GraphRAGPipeline
from src.advanced_rag import AdvancedRAGPipeline
from src.evaluation import RAGEvaluator


class BenchmarkSuite:
    """
    Comprehensive benchmarking suite for RAG systems
    """
    
    def __init__(
        self,
        rag_pipeline: RAGPipeline,
        graph_rag_pipeline: Optional[GraphRAGPipeline] = None,
        advanced_rag_pipeline: Optional[AdvancedRAGPipeline] = None
    ):
        """
        Initialize benchmark suite
        
        Args:
            rag_pipeline: Standard RAG pipeline
            graph_rag_pipeline: Graph RAG pipeline (optional)
            advanced_rag_pipeline: Advanced RAG pipeline (optional)
        """
        self.rag_pipeline = rag_pipeline
        self.graph_rag_pipeline = graph_rag_pipeline
        self.advanced_rag_pipeline = advanced_rag_pipeline
        self.results_dir = "results"
        os.makedirs(self.results_dir, exist_ok=True)
        
    def benchmark_retrieval_speed(
        self,
        queries: List[str],
        top_k: int = 5,
        num_runs: int = 3
    ) -> Dict:
        """
        Benchmark retrieval speed for different methods
        
        Args:
            queries: List of test queries
            top_k: Number of results
            num_runs: Number of runs for averaging
            
        Returns:
            Performance metrics dictionary
        """
        results = {
            "rag": [],
            "graph_rag": [],
            "advanced_rag": []
        }
        
        # Benchmark standard RAG
        for _ in range(num_runs):
            start = time.time()
            for query in queries:
                self.rag_pipeline.retrieve(query, top_k=top_k)
            elapsed = time.time() - start
            results["rag"].append(elapsed / len(queries))
        
        # Benchmark Graph RAG
        if self.graph_rag_pipeline:
            for _ in range(num_runs):
                start = time.time()
                for query in queries:
                    self.graph_rag_pipeline.graph_retrieve(query, top_k=top_k)
                elapsed = time.time() - start
                results["graph_rag"].append(elapsed / len(queries))
        
        # Benchmark Advanced RAG
        if self.advanced_rag_pipeline:
            for _ in range(num_runs):
                start = time.time()
                for query in queries:
                    self.advanced_rag_pipeline.advanced_retrieve(query, top_k=top_k)
                elapsed = time.time() - start
                results["advanced_rag"].append(elapsed / len(queries))
        
        # Calculate statistics
        stats = {}
        for method, times in results.items():
            if times:
                stats[method] = {
                    "mean": float(np.mean(times)),
                    "std": float(np.std(times)),
                    "min": float(np.min(times)),
                    "max": float(np.max(times)),
                    "median": float(np.median(times))
                }
        
        return stats
    
    def benchmark_retrieval_quality(
        self,
        queries: List[str],
        ground_truths: Optional[List[str]] = None,
        top_k: int = 5
    ) -> Dict:
        """
        Benchmark retrieval quality using multiple metrics
        
        Args:
            queries: List of test queries
            ground_truths: Ground truth answers (optional)
            top_k: Number of results
            
        Returns:
            Quality metrics dictionary
        """
        evaluator = RAGEvaluator(
            self.rag_pipeline,
            self.graph_rag_pipeline
        )
        
        results = {}
        
        # Evaluate standard RAG
        rag_dataset = evaluator.create_evaluation_dataset(queries, ground_truths)
        rag_metrics = evaluator.evaluate_rag(rag_dataset)
        results["rag"] = rag_metrics
        
        # Evaluate Graph RAG
        if self.graph_rag_pipeline:
            graph_rag_metrics = evaluator.evaluate_graph_rag(queries, ground_truths)
            results["graph_rag"] = graph_rag_metrics
        
        # Evaluate Advanced RAG
        if self.advanced_rag_pipeline:
            examples = []
            for i, query in enumerate(queries):
                retrieved_chunks = self.advanced_rag_pipeline.advanced_retrieve(query, top_k=top_k)
                context = [chunk['text'] for chunk in retrieved_chunks]
                answer = evaluator._generate_answer_from_context(query, context)
                
                example = {
                    "question": query,
                    "contexts": context,
                    "answer": answer
                }
                if ground_truths and i < len(ground_truths):
                    example["ground_truth"] = ground_truths[i]
                examples.append(example)
            
            advanced_rag_metrics = evaluator.evaluate_rag(examples)
            results["advanced_rag"] = advanced_rag_metrics
        
        return results
    
    def comprehensive_benchmark(
        self,
        queries: List[str],
        ground_truths: Optional[List[str]] = None,
        top_k: int = 5
    ) -> Dict:
        """
        Run comprehensive benchmark including speed and quality
        
        Args:
            queries: List of test queries
            ground_truths: Ground truth answers (optional)
            top_k: Number of results
            
        Returns:
            Complete benchmark results
        """
        print("Running comprehensive benchmark...")
        
        # Speed benchmark
        print("Benchmarking retrieval speed...")
        speed_results = self.benchmark_retrieval_speed(queries, top_k=top_k)
        
        # Quality benchmark
        print("Benchmarking retrieval quality...")
        quality_results = self.benchmark_retrieval_quality(queries, ground_truths, top_k=top_k)
        
        # Combine results
        results = {
            "timestamp": datetime.now().isoformat(),
            "num_queries": len(queries),
            "top_k": top_k,
            "speed_metrics": speed_results,
            "quality_metrics": quality_results
        }
        
        # Save results
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        results_file = os.path.join(self.results_dir, f"benchmark_{timestamp}.json")
        with open(results_file, 'w') as f:
            json.dump(results, f, indent=2)
        
        print(f"Benchmark results saved to {results_file}")
        
        return results
    
    def compare_methods(self, benchmark_results: Dict) -> pd.DataFrame:
        """
        Create comparison DataFrame from benchmark results
        
        Args:
            benchmark_results: Results from comprehensive_benchmark
            
        Returns:
            Comparison DataFrame
        """
        comparison_data = []
        
        speed_metrics = benchmark_results.get("speed_metrics", {})
        quality_metrics = benchmark_results.get("quality_metrics", {})
        
        for method in set(list(speed_metrics.keys()) + list(quality_metrics.keys())):
            row = {"method": method}
            
            # Speed metrics
            if method in speed_metrics:
                row["avg_retrieval_time"] = speed_metrics[method].get("mean", 0)
                row["std_retrieval_time"] = speed_metrics[method].get("std", 0)
            
            # Quality metrics
            if method in quality_metrics:
                row["faithfulness"] = quality_metrics[method].get("faithfulness", 0)
                row["answer_relevancy"] = quality_metrics[method].get("answer_relevancy", 0)
                row["context_precision"] = quality_metrics[method].get("context_precision", 0)
                row["context_recall"] = quality_metrics[method].get("context_recall", 0)
                row["average_score"] = quality_metrics[method].get("average_score", 0)
            
            comparison_data.append(row)
        
        return pd.DataFrame(comparison_data)
    
    def load_benchmark_results(self, filename: str) -> Dict:
        """Load saved benchmark results"""
        filepath = os.path.join(self.results_dir, filename)
        if os.path.exists(filepath):
            with open(filepath, 'r') as f:
                return json.load(f)
        return {}
    
    def list_benchmark_results(self) -> List[str]:
        """List all saved benchmark results"""
        files = [f for f in os.listdir(self.results_dir) if f.startswith("benchmark_")]
        return sorted(files, reverse=True)

