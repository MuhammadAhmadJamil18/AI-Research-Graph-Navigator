"""
Hybrid Search Implementation
Combines semantic search (vector) with keyword search (BM25)
"""
from typing import List, Dict
import numpy as np
from rank_bm25 import BM25Okapi
from src.rag_pipeline import RAGPipeline


class HybridSearch:
    """Hybrid search combining semantic and keyword-based retrieval"""
    
    def __init__(self, rag_pipeline: RAGPipeline, alpha: float = 0.7):
        """
        Initialize hybrid search
        
        Args:
            rag_pipeline: RAGPipeline instance
            alpha: Weight for semantic search (1-alpha for keyword search)
        """
        self.rag_pipeline = rag_pipeline
        self.alpha = alpha
        self.bm25 = None
        self.documents = []
        self._build_bm25_index()
    
    def _build_bm25_index(self):
        """Build BM25 index from documents in vector DB"""
        # Get all documents from collection
        all_docs = self.rag_pipeline.collection.get()
        
        if all_docs and all_docs.get('documents'):
            self.documents = all_docs['documents']
            # Tokenize documents for BM25
            tokenized_docs = [doc.lower().split() for doc in self.documents]
            self.bm25 = BM25Okapi(tokenized_docs)
    
    def search(
        self,
        query: str,
        top_k: int = 5,
        alpha: float = None
    ) -> List[Dict]:
        """
        Hybrid search combining semantic and keyword search
        
        Args:
            query: Search query
            top_k: Number of results to return
            alpha: Override default alpha weight
            
        Returns:
            List of retrieved documents with hybrid scores
        """
        if alpha is None:
            alpha = self.alpha
        
        # Semantic search
        semantic_results = self.rag_pipeline.retrieve(query, top_k=top_k * 2)
        
        # Keyword search (BM25)
        keyword_scores = []
        if self.bm25:
            tokenized_query = query.lower().split()
            keyword_scores = self.bm25.get_scores(tokenized_query)
        
        # Combine scores
        combined_results = {}
        
        # Normalize semantic scores (distance to similarity)
        for result in semantic_results:
            doc_id = f"{result['metadata'].get('paper_id')}_{result['metadata'].get('chunk_index', 0)}"
            semantic_score = 1 - result.get('distance', 1.0)  # Convert distance to similarity
            
            # Get BM25 score
            try:
                doc_index = self.documents.index(result['text'])
                keyword_score = keyword_scores[doc_index] if doc_index < len(keyword_scores) else 0
            except (ValueError, IndexError):
                keyword_score = 0
            
            # Normalize keyword score (0-1 range)
            if keyword_scores:
                max_keyword = max(keyword_scores) if keyword_scores else 1
                keyword_score = keyword_score / max_keyword if max_keyword > 0 else 0
            
            # Hybrid score
            hybrid_score = alpha * semantic_score + (1 - alpha) * keyword_score
            
            combined_results[doc_id] = {
                **result,
                "semantic_score": semantic_score,
                "keyword_score": keyword_score,
                "hybrid_score": hybrid_score
            }
        
        # Sort by hybrid score and return top_k
        sorted_results = sorted(
            combined_results.values(),
            key=lambda x: x['hybrid_score'],
            reverse=True
        )
        
        return sorted_results[:top_k]
    
    def tune_alpha(
        self,
        queries: List[str],
        ground_truth: List[List[str]] = None,
        alpha_values: List[float] = [0.0, 0.3, 0.5, 0.7, 1.0]
    ) -> Dict:
        """
        Tune alpha parameter for optimal performance
        
        Args:
            queries: List of query strings
            ground_truth: Ground truth relevant documents
            alpha_values: Alpha values to test
            
        Returns:
            Results for each alpha value
        """
        results = {}
        
        for alpha in alpha_values:
            self.alpha = alpha
            precisions = []
            recalls = []
            
            for i, query in enumerate(queries):
                retrieved = self.search(query, top_k=5, alpha=alpha)
                retrieved_ids = [r['metadata'].get('paper_id') for r in retrieved]
                
                if ground_truth and i < len(ground_truth):
                    relevant_ids = set(ground_truth[i])
                    retrieved_set = set(retrieved_ids)
                    
                    if len(retrieved_set) > 0:
                        precision = len(retrieved_set & relevant_ids) / len(retrieved_set)
                        recall = len(retrieved_set & relevant_ids) / len(relevant_ids) if len(relevant_ids) > 0 else 0
                        precisions.append(precision)
                        recalls.append(recall)
            
            results[alpha] = {
                "precision": np.mean(precisions) if precisions else 0,
                "recall": np.mean(recalls) if recalls else 0,
                "f1": 2 * np.mean(precisions) * np.mean(recalls) / (np.mean(precisions) + np.mean(recalls))
                if (np.mean(precisions) + np.mean(recalls)) > 0 else 0
            }
        
        return results

