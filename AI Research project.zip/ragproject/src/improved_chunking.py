"""
Improved Chunking Strategies
Semantic and section-aware chunking for better retrieval
"""
from typing import List, Dict
import re
from abc import ABC, abstractmethod


class ChunkingStrategy(ABC):
    """Abstract base class for chunking strategies"""
    
    @abstractmethod
    def chunk(self, paper: Dict) -> List[Dict]:
        """Chunk a paper into segments"""
        pass


class SemanticChunker(ChunkingStrategy):
    """
    Section-aware semantic chunking
    
    Strategy:
    1. Identify paper sections (Introduction, Methods, Results, etc.)
    2. Chunk within sections to preserve context
    3. Use semantic boundaries (sentences) when possible
    """
    
    def __init__(
        self,
        chunk_size: int = 500,
        overlap: int = 50,
        respect_sections: bool = True
    ):
        self.chunk_size = chunk_size
        self.overlap = overlap
        self.respect_sections = respect_sections
    
    def chunk(self, paper: Dict) -> List[Dict]:
        """Chunk paper with section awareness"""
        try:
            # Validate input
            if not isinstance(paper, dict):
                return []
            
            if 'id' not in paper or 'title' not in paper:
                return []
            
            # Safely get text content
            title = str(paper.get('title', ''))
            summary = str(paper.get('summary', ''))
            text = f"{title}\n\n{summary}".strip()
            
            # Return empty if no text
            if not text:
                return []
            
            if self.respect_sections:
                sections = self._identify_sections(text)
                chunks = []
                for section_name, section_text in sections:
                    if section_text:  # Only process non-empty sections
                        section_chunks = self._chunk_section(
                            section_text,
                            section_name,
                            paper['id'],
                            title
                        )
                        chunks.extend(section_chunks)
                return chunks if chunks else self._chunk_fixed_size(text, paper)
            else:
                return self._chunk_fixed_size(text, paper)
        except Exception as e:
            # Return empty list on error instead of crashing
            print(f"Error chunking paper {paper.get('id', 'unknown')}: {e}")
            return []
    
    def _identify_sections(self, text: str) -> List[tuple]:
        """Identify paper sections"""
        # Common section headers
        section_patterns = [
            (r'(?:^|\n)\s*(?:Abstract|Summary)\s*[:\n]', 'Abstract'),
            (r'(?:^|\n)\s*(?:Introduction|Intro)\s*[:\n]', 'Introduction'),
            (r'(?:^|\n)\s*(?:Method|Methodology|Approach)\s*[:\n]', 'Methods'),
            (r'(?:^|\n)\s*(?:Result|Finding|Experiment)\s*[:\n]', 'Results'),
            (r'(?:^|\n)\s*(?:Conclusion|Discussion)\s*[:\n]', 'Conclusion'),
        ]
        
        sections = []
        last_pos = 0
        
        # Find section boundaries
        section_starts = []
        for pattern, name in section_patterns:
            matches = list(re.finditer(pattern, text, re.IGNORECASE | re.MULTILINE))
            for match in matches:
                section_starts.append((match.start(), name))
        
        section_starts.sort(key=lambda x: x[0])
        
        # Extract sections
        for i, (start, name) in enumerate(section_starts):
            end = section_starts[i+1][0] if i+1 < len(section_starts) else len(text)
            section_text = text[start:end].strip()
            if section_text:
                sections.append((name, section_text))
        
        # If no sections found, treat as single section
        if not sections:
            sections.append(('Full Text', text))
        
        return sections
    
    def _chunk_section(
        self,
        section_text: str,
        section_name: str,
        paper_id: str,
        title: str
    ) -> List[Dict]:
        """Chunk a section into smaller pieces"""
        chunks = []
        sentences = self._split_sentences(section_text)
        
        current_chunk = []
        current_length = 0
        
        for sentence in sentences:
            sentence_length = len(sentence)
            
            if current_length + sentence_length > self.chunk_size and current_chunk:
                # Save current chunk
                chunk_text = ' '.join(current_chunk)
                chunks.append({
                    "paper_id": paper_id,
                    "title": title,
                    "chunk_text": chunk_text,
                    "chunk_index": len(chunks),
                    "section": section_name,
                    "start_pos": 0,  # Would track actual positions
                    "end_pos": len(chunk_text)
                })
                
                # Start new chunk with overlap
                overlap_sentences = current_chunk[-2:] if len(current_chunk) >= 2 else current_chunk
                current_chunk = overlap_sentences + [sentence]
                current_length = sum(len(s) for s in current_chunk)
            else:
                current_chunk.append(sentence)
                current_length += sentence_length
        
        # Add remaining chunk
        if current_chunk:
            chunk_text = ' '.join(current_chunk)
            chunks.append({
                "paper_id": paper_id,
                "title": title,
                "chunk_text": chunk_text,
                "chunk_index": len(chunks),
                "section": section_name,
                "start_pos": 0,
                "end_pos": len(chunk_text)
            })
        
        return chunks
    
    def _split_sentences(self, text: str) -> List[str]:
        """Split text into sentences"""
        # Simple sentence splitting
        sentences = re.split(r'[.!?]+\s+', text)
        return [s.strip() for s in sentences if s.strip()]
    
    def _chunk_fixed_size(self, text: str, paper: Dict) -> List[Dict]:
        """Fallback to fixed-size chunking"""
        chunks = []
        start = 0
        
        while start < len(text):
            end = start + self.chunk_size
            chunk_text = text[start:end]
            
            chunks.append({
                "paper_id": paper['id'],
                "title": paper['title'],
                "chunk_text": chunk_text,
                "chunk_index": len(chunks),
                "section": "Full Text",
                "start_pos": start,
                "end_pos": end
            })
            
            start = end - self.overlap
        
        return chunks


class FixedChunker(ChunkingStrategy):
    """Fixed-size chunking (baseline)"""
    
    def __init__(self, chunk_size: int = 500, overlap: int = 50):
        self.chunk_size = chunk_size
        self.overlap = overlap
    
    def chunk(self, paper: Dict) -> List[Dict]:
        """Simple fixed-size chunking"""
        try:
            # Validate input
            if not isinstance(paper, dict):
                return []
            
            if 'id' not in paper or 'title' not in paper:
                return []
            
            # Safely get text content
            title = str(paper.get('title', ''))
            summary = str(paper.get('summary', ''))
            text = f"{title}\n\n{summary}".strip()
            
            # Return empty if no text
            if not text:
                return []
            
            chunks = []
            start = 0
            
            while start < len(text):
                end = min(start + self.chunk_size, len(text))
                chunk_text = text[start:end]
                
                if chunk_text.strip():  # Only add non-empty chunks
                    chunks.append({
                        "paper_id": paper['id'],
                        "title": title,
                        "chunk_text": chunk_text,
                        "chunk_index": len(chunks),
                        "start_pos": start,
                        "end_pos": end
                    })
                
                # Move to next position with overlap
                start = end - self.overlap
                if start >= len(text):
                    break
                if start < 0:
                    start = 0
            
            return chunks
        except Exception as e:
            # Return empty list on error instead of crashing
            print(f"Error chunking paper {paper.get('id', 'unknown')}: {e}")
            return []

