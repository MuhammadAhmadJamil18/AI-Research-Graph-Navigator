"""
Context Deduplication for RAG
Removes redundant context to improve efficiency and quality
"""
from typing import List, Dict
from sentence_transformers import SentenceTransformer
import numpy as np
from collections import defaultdict


class ContextDeduplicator:
    """
    Removes duplicate or highly similar chunks from retrieved context
    
    Strategy:
    1. Compute embeddings for all chunks
    2. Cluster similar chunks
    3. Keep most relevant from each cluster
    """
    
    def __init__(
        self,
        similarity_threshold: float = 0.85,
        embedding_model: str = "all-MiniLM-L-6-v2"
    ):
        """
        Initialize deduplicator
        
        Args:
            similarity_threshold: Cosine similarity threshold for duplicates
            embedding_model: Model for computing embeddings
        """
        self.similarity_threshold = similarity_threshold
        self.embedding_model = SentenceTransformer(embedding_model)
    
    def deduplicate(
        self,
        chunks: List[Dict],
        preserve_order: bool = True
    ) -> List[Dict]:
        """
        Remove duplicate chunks
        
        Args:
            chunks: List of chunk dictionaries
            preserve_order: Whether to preserve original order
            
        Returns:
            Deduplicated chunks
        """
        if len(chunks) <= 1:
            return chunks
        
        # Compute embeddings
        texts = [chunk['text'] for chunk in chunks]
        embeddings = self.embedding_model.encode(texts)
        
        # Find duplicates
        to_remove = set()
        for i in range(len(chunks)):
            if i in to_remove:
                continue
            
            for j in range(i + 1, len(chunks)):
                if j in to_remove:
                    continue
                
                # Compute cosine similarity
                similarity = np.dot(embeddings[i], embeddings[j]) / (
                    np.linalg.norm(embeddings[i]) * np.linalg.norm(embeddings[j])
                )
                
                if similarity >= self.similarity_threshold:
                    # Keep chunk with higher relevance score
                    score_i = chunks[i].get('distance', 1.0)  # Lower distance = better
                    score_j = chunks[j].get('distance', 1.0)
                    
                    if score_i <= score_j:
                        to_remove.add(j)
                    else:
                        to_remove.add(i)
                        break
        
        # Filter out duplicates
        deduplicated = [
            chunk for i, chunk in enumerate(chunks)
            if i not in to_remove
        ]
        
        return deduplicated
    
    def cluster_similar(
        self,
        chunks: List[Dict],
        max_cluster_size: int = 3
    ) -> List[Dict]:
        """
        Cluster similar chunks and keep best from each cluster
        
        Args:
            chunks: List of chunks
            max_cluster_size: Maximum chunks per cluster
            
        Returns:
            Representative chunks from each cluster
        """
        if len(chunks) <= 1:
            return chunks
        
        texts = [chunk['text'] for chunk in chunks]
        embeddings = self.embedding_model.encode(texts)
        
        # Simple clustering: group similar chunks
        clusters = []
        used = set()
        
        for i, chunk in enumerate(chunks):
            if i in used:
                continue
            
            cluster = [i]
            used.add(i)
            
            for j in range(i + 1, len(chunks)):
                if j in used:
                    continue
                
                similarity = np.dot(embeddings[i], embeddings[j]) / (
                    np.linalg.norm(embeddings[i]) * np.linalg.norm(embeddings[j])
                )
                
                if similarity >= self.similarity_threshold:
                    cluster.append(j)
                    used.add(j)
                    
                    if len(cluster) >= max_cluster_size:
                        break
            
            clusters.append(cluster)
        
        # Select best chunk from each cluster
        representative_chunks = []
        for cluster_indices in clusters:
            cluster_chunks = [chunks[i] for i in cluster_indices]
            
            # Sort by relevance (lower distance = better)
            cluster_chunks.sort(key=lambda x: x.get('distance', 1.0))
            
            # Take top chunk(s) from cluster
            representative_chunks.append(cluster_chunks[0])
        
        return representative_chunks

