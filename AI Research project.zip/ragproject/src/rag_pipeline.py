"""
RAG (Retrieval-Augmented Generation) Pipeline
"""

import os
import warnings
import sys
import subprocess

# Suppress Pydantic BaseSettings warnings (ChromaDB compatibility)
warnings.filterwarnings("ignore", message=".*BaseSettings.*pydantic-settings.*")
warnings.filterwarnings("ignore", message=".*Pydantic V1.*Python 3.14.*")

# Workaround for ChromaDB BaseSettings issue - patch pydantic before chromadb imports
try:
    # Try to import pydantic-settings first and patch pydantic
    try:
        import pydantic_settings
        # Make BaseSettings available in pydantic namespace for chromadb compatibility
        import pydantic
        if not hasattr(pydantic, 'BaseSettings'):
            pydantic.BaseSettings = pydantic_settings.BaseSettings
    except ImportError:
        # pydantic-settings not installed - will try to install or use fallback
        pass
except:
    pass

# Workaround for ChromaDB's default embedding function requiring onnxruntime
# We need to patch it before ChromaDB's Collection class is defined
try:
    # First, try to import and patch the embedding functions module
    import chromadb.utils.embedding_functions as ef

    # Create a dummy embedding function
    class DummyEmbeddingFunction:
        def __call__(self, input):
            return []

    # Patch DefaultEmbeddingFunction before ChromaDB uses it
    original_default = getattr(ef, "DefaultEmbeddingFunction", None)

    def patched_default():
        return DummyEmbeddingFunction()

    ef.DefaultEmbeddingFunction = patched_default

    # Now import ChromaDB (it will use our patched function)
    # Suppress warnings during import
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        import chromadb
        from chromadb.config import Settings

except Exception as e1:
    # If patching fails, try to import anyway and handle errors later
    try:
        # Try installing pydantic-settings if BaseSettings error
        if "BaseSettings" in str(e1) or "pydantic-settings" in str(e1) or "PydanticImportError" in str(type(e1).__name__):
            try:
                import pydantic_settings
                # Patch pydantic to have BaseSettings for chromadb compatibility
                import pydantic
                if not hasattr(pydantic, 'BaseSettings'):
                    pydantic.BaseSettings = pydantic_settings.BaseSettings
            except ImportError:
                print("Warning: pydantic-settings not found. Attempting to install...")
                import subprocess
                try:
                    subprocess.check_call([sys.executable, "-m", "pip", "install", "pydantic-settings>=2.0.0", "--quiet"], 
                                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    import pydantic_settings
                    import pydantic
                    if not hasattr(pydantic, 'BaseSettings'):
                        pydantic.BaseSettings = pydantic_settings.BaseSettings
                except:
                    print("Could not automatically install pydantic-settings. Please run: pip install pydantic-settings>=2.0.0")
        
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            import chromadb
            from chromadb.config import Settings
            from chromadb.utils import embedding_functions as ef
    except Exception as e2:
        print(f"Warning: ChromaDB import issue: {e2}")
        print("Note: If you see BaseSettings warnings, ensure pydantic-settings>=2.0.0 is installed.")
        print("Attempting to install pydantic-settings...")
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", "pydantic-settings>=2.0.0", "--quiet"], 
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            # Try importing again after installing
            try:
                import pydantic_settings
                import pydantic
                if not hasattr(pydantic, 'BaseSettings'):
                    pydantic.BaseSettings = pydantic_settings.BaseSettings
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    import chromadb
                    from chromadb.config import Settings
                    from chromadb.utils import embedding_functions as ef
                print("Successfully installed pydantic-settings and imported ChromaDB")
            except Exception as e3:
                print(f"Still failed after installing pydantic-settings: {e3}")
                chromadb = None
                Settings = None
                ef = None
        except Exception as install_error:
            print(f"Could not automatically install pydantic-settings: {install_error}")
            print("Please run manually: pip install pydantic-settings>=2.0.0 chromadb")
            chromadb = None
            Settings = None
            ef = None

from typing import Dict, List

import numpy as np
from sentence_transformers import SentenceTransformer


class RAGPipeline:
    """RAG pipeline for semantic search and generation"""

    def __init__(
        self,
        embedding_model: str = "all-MiniLM-L6-v2",
        chroma_dir: str = "chroma_db",
        collection_name: str = "research_papers",
    ) -> None:
        """
        Initialize RAG pipeline with embedding model and vector database.

        Sets up the sentence transformer model for embeddings and initializes
        a ChromaDB collection for storing and retrieving document chunks.

        Args:
            embedding_model: Sentence transformer model name from Hugging Face.
                Default: "all-MiniLM-L6-v2" (fast, good quality)
            chroma_dir: Directory path for ChromaDB persistent storage.
                Default: "chroma_db"
            collection_name: Name of the ChromaDB collection.
                Default: "research_papers"

        Returns:
            None

        Raises:
            ImportError: If ChromaDB cannot be imported
            RuntimeError: If ChromaDB collection creation fails

        Example:
            >>> pipeline = RAGPipeline(
            ...     embedding_model="all-MiniLM-L6-v2",
            ...     chroma_dir="./vector_db",
            ...     collection_name="papers"
            ... )
        """
        if chromadb is None:
            # Try to install chromadb automatically
            print("ChromaDB not found. Attempting to install...")
            try:
                subprocess.check_call([sys.executable, "-m", "pip", "install", "chromadb", "pydantic-settings>=2.0.0", "--quiet"], 
                                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                # Try importing again
                try:
                    import pydantic_settings
                    import pydantic
                    if not hasattr(pydantic, 'BaseSettings'):
                        pydantic.BaseSettings = pydantic_settings.BaseSettings
                    with warnings.catch_warnings():
                        warnings.simplefilter("ignore")
                        import chromadb
                        from chromadb.config import Settings
                    print("Successfully installed and imported ChromaDB")
                    # Update the module-level chromadb variable
                    globals()['chromadb'] = chromadb
                    globals()['Settings'] = Settings
                except Exception as e3:
                    error_msg = (
                        "ChromaDB could not be imported even after installation attempt.\n"
                        f"Error: {str(e3)}\n"
                        "Please run manually: pip install chromadb pydantic-settings>=2.0.0\n"
                        "If using Python 3.14+, ensure pydantic-settings is installed."
                    )
                    raise ImportError(error_msg) from e3
            except Exception as install_error:
                error_msg = (
                    "ChromaDB could not be imported. Automatic installation failed.\n"
                    f"Installation error: {str(install_error)}\n"
                    "Please run manually: pip install chromadb pydantic-settings>=2.0.0\n"
                    "If using Python 3.14+, ensure pydantic-settings is installed."
                )
                raise ImportError(error_msg) from install_error

        self.embedding_model = SentenceTransformer(embedding_model)
        self.chroma_dir = chroma_dir
        os.makedirs(chroma_dir, exist_ok=True)

        # Initialize ChromaDB
        self.client = chromadb.PersistentClient(
            path=chroma_dir, settings=Settings(anonymized_telemetry=False)
        )

        # Create a simple embedding function that does nothing (we provide our own embeddings)
        class DummyEmbeddingFunction:
            def __call__(self, input):
                # This should never be called since we provide embeddings
                return []

        # Get or create collection without default embedding function
        try:
            self.collection = self.client.get_or_create_collection(
                name=collection_name,
                embedding_function=DummyEmbeddingFunction(),
                metadata={"hnsw:space": "cosine"},
            )
        except Exception:
            # Fallback: try without embedding function (some ChromaDB versions)
            try:
                self.collection = self.client.get_or_create_collection(
                    name=collection_name, metadata={"hnsw:space": "cosine"}
                )
            except Exception:
                # Last resort: create collection with minimal config
                try:
                    self.collection = self.client.create_collection(
                        name=collection_name, metadata={"hnsw:space": "cosine"}
                    )
                except Exception as e3:
                    raise RuntimeError(f"Failed to create ChromaDB collection: {e3}")

    def add_documents(self, chunks: List[Dict]) -> None:
        """
        Add document chunks to vector database.

        Validates chunks, checks for duplicates, generates embeddings,
        and adds them to ChromaDB. Skips invalid or duplicate chunks.

        Args:
            chunks: List of chunk dictionaries with required keys:
                - 'chunk_text': Text content of the chunk
                - 'paper_id': Unique identifier for the paper
                - 'chunk_index': Index of chunk within the paper
                - 'title': (optional) Paper title for metadata

        Returns:
            None (modifies ChromaDB collection in place)

        Raises:
            RuntimeError: If embedding generation fails
            Exception: If ChromaDB operations fail (logged, not re-raised)

        Note:
            Empty chunks and duplicates are silently skipped.
            Errors are logged but don't crash the application.
        """
        if not chunks:
            return

        try:
            # Validate chunks structure
            valid_chunks = []
            for chunk in chunks:
                if not isinstance(chunk, dict):
                    continue
                if (
                    "chunk_text" not in chunk
                    or "paper_id" not in chunk
                    or "chunk_index" not in chunk
                ):
                    continue
                if not chunk.get("chunk_text", "").strip():
                    continue  # Skip empty chunks
                valid_chunks.append(chunk)

            if not valid_chunks:
                print("No valid chunks to add")
                return

            ids = [f"{chunk['paper_id']}_{chunk['chunk_index']}" for chunk in valid_chunks]

            # Check for duplicates (skip if already exists)
            existing_ids = set()
            try:
                existing = self.collection.get(ids=ids)
                if existing and existing.get("ids"):
                    existing_ids = set(existing["ids"])
            except Exception:
                # Collection might be empty or query might fail
                pass

            # Filter out existing chunks
            new_chunks = [c for i, c in enumerate(valid_chunks) if ids[i] not in existing_ids]
            if not new_chunks:
                print(f"All {len(valid_chunks)} chunks already exist in database")
                return

            new_texts = [chunk["chunk_text"] for chunk in new_chunks]
            new_ids = [f"{chunk['paper_id']}_{chunk['chunk_index']}" for chunk in new_chunks]

            # Generate embeddings with error handling and batch optimization
            try:
                # For large batches, process in smaller chunks to prevent memory issues
                if len(new_texts) > 100:
                    # Process in batches of 50 to prevent memory overflow
                    all_embeddings = []
                    embed_batch_size = 50
                    for embed_i in range(0, len(new_texts), embed_batch_size):
                        embed_batch = new_texts[embed_i : embed_i + embed_batch_size]
                        batch_embeddings = self.embedding_model.encode(
                            embed_batch,
                            show_progress_bar=False,
                            convert_to_numpy=True,
                            normalize_embeddings=True,
                        )
                        all_embeddings.append(batch_embeddings)
                    embeddings = np.vstack(all_embeddings)
                else:
                    embeddings = self.embedding_model.encode(
                        new_texts,
                        show_progress_bar=False,
                        convert_to_numpy=True,
                        normalize_embeddings=True,
                    )
            except Exception as embed_error:
                print(f"Error generating embeddings: {embed_error}")
                raise RuntimeError(f"Failed to generate embeddings: {embed_error}")

            # Prepare metadata
            metadatas = []
            for chunk in new_chunks:
                try:
                    metadata = {
                        "paper_id": str(chunk["paper_id"]),
                        "title": str(chunk.get("title", ""))[:500],  # Limit title length
                        "chunk_index": int(chunk["chunk_index"]),
                    }
                    metadatas.append(metadata)
                except Exception:
                    # Use minimal metadata if there's an error
                    metadatas.append(
                        {
                            "paper_id": str(chunk.get("paper_id", "unknown")),
                            "title": "",
                            "chunk_index": 0,
                        }
                    )

            # Add to ChromaDB with retry logic
            try:
                self.collection.add(
                    embeddings=embeddings.tolist(),
                    documents=new_texts,
                    ids=new_ids,
                    metadatas=metadatas,
                )
                print(f"Added {len(new_chunks)} chunks to vector database")
            except Exception as add_error:
                print(f"Error adding to ChromaDB: {add_error}")
                # Try adding in smaller batches if batch fails
                if len(new_chunks) > 1:
                    print("Retrying with smaller batches...")
                    batch_size = max(1, len(new_chunks) // 2)
                    for i in range(0, len(new_chunks), batch_size):
                        batch = new_chunks[i : i + batch_size]
                        try:
                            batch_texts = [chunk["chunk_text"] for chunk in batch]
                            batch_ids = [
                                f"{chunk['paper_id']}_{chunk['chunk_index']}" for chunk in batch
                            ]
                            batch_embeddings = self.embedding_model.encode(
                                batch_texts, show_progress_bar=False
                            )
                            batch_metadatas = [
                                {
                                    "paper_id": str(chunk["paper_id"]),
                                    "title": str(chunk.get("title", ""))[:500],
                                    "chunk_index": int(chunk["chunk_index"]),
                                }
                                for chunk in batch
                            ]
                            self.collection.add(
                                embeddings=batch_embeddings.tolist(),
                                documents=batch_texts,
                                ids=batch_ids,
                                metadatas=batch_metadatas,
                            )
                            print(f"Added batch of {len(batch)} chunks")
                        except Exception as batch_error:
                            print(f"Failed to add batch {i//batch_size + 1}: {batch_error}")
                            continue
                else:
                    raise
        except Exception as e:
            print(f"Error adding documents to ChromaDB: {e}")
            import traceback

            traceback.print_exc()
            # Don't re-raise to prevent server crash - just log the error
            # The calling code can handle the partial success

    def retrieve(self, query: str, top_k: int = 5) -> List[Dict]:
        """
        Retrieve relevant chunks for a query

        Args:
            query: Search query
            top_k: Number of results to return

        Returns:
            List of relevant chunks with metadata
        """
        try:
            if not query or not query.strip():
                return []

            # Generate query embedding
            query_embedding = self.embedding_model.encode([query]).tolist()[0]

            # Check if collection has documents
            if self.collection.count() == 0:
                print("Warning: Vector database is empty")
                return []

            # Search in ChromaDB
            results = self.collection.query(
                query_embeddings=[query_embedding], n_results=min(top_k, self.collection.count())
            )

            # Format results
            retrieved_chunks = []
            if results.get("documents") and len(results["documents"][0]) > 0:
                for i in range(len(results["documents"][0])):
                    chunk = {
                        "text": results["documents"][0][i],
                        "metadata": (
                            results["metadatas"][0][i]
                            if results.get("metadatas") and results["metadatas"][0]
                            else {}
                        ),
                        "distance": (
                            results["distances"][0][i]
                            if results.get("distances") and results["distances"][0]
                            else None
                        ),
                    }
                    retrieved_chunks.append(chunk)

            return retrieved_chunks
        except Exception as e:
            print(f"Error retrieving from ChromaDB: {e}")
            return []

    def format_context(self, chunks: List[Dict]) -> str:
        """
        Format retrieved chunks into a context string for LLM.

        Creates a numbered list of chunks with titles and text content,
        suitable for inclusion in LLM prompts.

        Args:
            chunks: List of chunk dictionaries with 'text' and 'metadata' keys

        Returns:
            Formatted string with numbered chunks, each containing:
            - Title from metadata
            - Text content

        Example:
            >>> chunks = [{'text': 'Content...', 'metadata': {'title': 'Paper 1'}}]
            >>> context = pipeline.format_context(chunks)
            >>> print(context)
            [1] Title: Paper 1
            Content...
        """
        context_parts = []
        for i, chunk in enumerate(chunks, 1):
            title = chunk["metadata"].get("title", "Unknown")
            text = chunk["text"]
            context_parts.append(f"[{i}] Title: {title}\n{text}\n")
        return "\n".join(context_parts)

    def generate_prompt(self, query: str, context: str) -> str:
        """
        Generate a prompt for LLM with query and context.

        Creates a formatted prompt that instructs the LLM to answer
        the question based on the provided research paper context.

        Args:
            query: User's question or query string
            context: Formatted context string from retrieved chunks

        Returns:
            Complete prompt string ready for LLM input

        Example:
            >>> prompt = pipeline.generate_prompt(
            ...     "What is transformer architecture?",
            ...     "[1] Title: Paper 1\nContent about transformers..."
            ... )
        """
        prompt = f"""You are a helpful research assistant. Answer the question based on the following research paper excerpts.

Context from research papers:
{context}

Question: {query}

Answer:"""
        return prompt

    def get_collection_stats(self) -> Dict[str, int]:
        """
        Get statistics about the ChromaDB collection.

        Returns:
            Dictionary with collection statistics:
                - 'total_chunks': Number of chunks in the collection
                - 'collection_name': Name of the collection

        Example:
            >>> stats = pipeline.get_collection_stats()
            >>> print(f"Total chunks: {stats['total_chunks']}")
        """
        count = self.collection.count()
        return {"total_chunks": count, "collection_name": self.collection.name}
