"""
LLM Generation Module
Supports Ollama and Hugging Face transformers for answer generation
"""
from typing import Optional, Dict
import os


class LLMGenerator:
    """Generate answers using LLM (Ollama or Hugging Face)"""
    
    def __init__(
        self,
        provider: str = "ollama",
        model_name: str = "llama3.2",
        temperature: float = 0.7,
        max_tokens: int = 200
    ):
        """
        Initialize LLM generator
        
        Args:
            provider: "ollama" or "huggingface"
            model_name: Model name/identifier
            temperature: Generation temperature
            max_tokens: Maximum tokens to generate
        """
        self.provider = provider.lower()
        self.model_name = model_name
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.model = None
        self._initialize_model()
    
    def _initialize_model(self):
        """Initialize the LLM model based on provider"""
        if self.provider == "ollama":
            try:
                import ollama
                self.model = ollama
                # Test connection
                try:
                    ollama.list()
                except:
                    print("Warning: Ollama not available. Will use simplified generation.")
                    self.provider = "simplified"
            except ImportError:
                print("Warning: ollama package not installed. Using simplified generation.")
                self.provider = "simplified"
        
        elif self.provider == "huggingface":
            try:
                from transformers import pipeline
                self.model = pipeline(
                    "text-generation",
                    model=self.model_name,
                    device_map="auto"
                )
            except Exception as e:
                print(f"Warning: Could not load Hugging Face model: {e}. Using simplified generation.")
                self.provider = "simplified"
        
        else:
            self.provider = "simplified"
    
    def generate(
        self,
        prompt: str,
        context: Optional[str] = None
    ) -> str:
        """
        Generate answer from prompt
        
        Args:
            prompt: Full prompt including context and question
            context: Optional context (if not in prompt)
            
        Returns:
            Generated answer
        """
        if self.provider == "ollama" and self.model:
            try:
                response = self.model.generate(
                    model=self.model_name,
                    prompt=prompt,
                    options={
                        "temperature": self.temperature,
                        "num_predict": self.max_tokens
                    }
                )
                # Extract text from response
                if isinstance(response, dict):
                    return response.get("response", "").strip()
                elif isinstance(response, str):
                    return response.strip()
                else:
                    return str(response).strip()
            except Exception as e:
                print(f"Error generating with Ollama: {e}")
                return self._simplified_generation(prompt, context)
        
        elif self.provider == "huggingface" and self.model:
            try:
                result = self.model(
                    prompt,
                    max_length=len(prompt.split()) + self.max_tokens,
                    temperature=self.temperature,
                    do_sample=True,
                    num_return_sequences=1
                )
                if isinstance(result, list) and len(result) > 0:
                    generated_text = result[0].get("generated_text", "")
                    # Remove the prompt from the generated text
                    if generated_text.startswith(prompt):
                        generated_text = generated_text[len(prompt):].strip()
                    return generated_text
                return ""
            except Exception as e:
                print(f"Error generating with Hugging Face: {e}")
                return self._simplified_generation(prompt, context)
        
        else:
            return self._simplified_generation(prompt, context)
    
    def _simplified_generation(self, prompt: str, context: Optional[str] = None) -> str:
        """
        Simplified generation when LLM is not available
        Extracts relevant information from context
        """
        # Extract question from prompt
        if "Question:" in prompt:
            question = prompt.split("Question:")[-1].split("Answer:")[0].strip()
        else:
            question = prompt.split("\n")[-1].strip()
        
        # Extract context
        if context:
            context_text = context
        elif "Context from research papers:" in prompt:
            context_text = prompt.split("Context from research papers:")[1].split("Question:")[0].strip()
        else:
            context_text = prompt[:1000]  # First 1000 chars as context
        
        # Simple extraction-based answer
        # Try to find sentences that might answer the question
        sentences = context_text.split(". ")
        relevant_sentences = []
        
        question_lower = question.lower()
        question_words = set(question_lower.split())
        
        for sentence in sentences:
            sentence_lower = sentence.lower()
            # Check if sentence contains question words
            if any(word in sentence_lower for word in question_words if len(word) > 3):
                relevant_sentences.append(sentence.strip())
                if len(relevant_sentences) >= 3:
                    break
        
        if relevant_sentences:
            answer = ". ".join(relevant_sentences)
            if not answer.endswith("."):
                answer += "."
            return f"Based on the research papers:\n\n{answer}"
        else:
            # Fallback: return first few sentences
            first_sentences = ". ".join(sentences[:2])
            return f"Based on the research papers:\n\n{first_sentences}..."

