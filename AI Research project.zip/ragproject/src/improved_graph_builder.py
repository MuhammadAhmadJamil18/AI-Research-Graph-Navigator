"""
Improved Knowledge Graph Builder with NLP-based extraction and graph optimization
"""
import networkx as nx
import json
import os
from typing import List, Dict, Set, Tuple
from collections import defaultdict
import numpy as np

from src.entity_extractor import EntityExtractor


class ImprovedKnowledgeGraphBuilder:
    """
    Enhanced knowledge graph builder with:
    - NLP-based entity extraction
    - Confidence scoring
    - Graph pruning
    - Relationship weighting
    """
    
    def __init__(
        self,
        min_entity_confidence: float = 0.5,
        min_edge_weight: float = 0.3,
        use_pruning: bool = True
    ):
        """
        Initialize improved graph builder
        
        Args:
            min_entity_confidence: Minimum confidence for entities
            min_edge_weight: Minimum weight for edges
            use_pruning: Whether to prune low-confidence edges
        """
        self.graph = nx.MultiDiGraph()
        self.entity_extractor = EntityExtractor()
        self.min_entity_confidence = min_entity_confidence
        self.min_edge_weight = min_edge_weight
        self.use_pruning = use_pruning
        
    def build_graph(self, papers: List[Dict]):
        """
        Build knowledge graph with improved methods
        
        Args:
            papers: List of paper dictionaries
        """
        print("Building knowledge graph with NLP-based extraction...")
        
        # Phase 1: Extract entities with confidence scores
        paper_entities = {}
        for paper in papers:
            paper_id = paper['id']
            entities = self.entity_extractor.extract_entities(paper)
            
            # Filter by confidence
            entities = self.entity_extractor.filter_by_confidence(
                entities,
                self.min_entity_confidence
            )
            
            paper_entities[paper_id] = entities
            
            # Add paper node
            self.graph.add_node(
                paper_id,
                node_type="paper",
                title=paper.get('title', ''),
                summary=paper.get('summary', '')[:200],
                published=paper.get('published', ''),
                categories=paper.get('categories', [])
            )
        
        # Phase 2: Add entity nodes and edges with confidence
        for paper_id, entities in paper_entities.items():
            self._add_entity_nodes_and_edges(paper_id, entities)
        
        # Phase 3: Add similarity edges with weighted scores
        self._add_weighted_similarity_edges(papers, paper_entities)
        
        # Phase 4: Prune graph if enabled
        if self.use_pruning:
            self._prune_graph()
        
        print(f"Graph built: {self.graph.number_of_nodes()} nodes, {self.graph.number_of_edges()} edges")
    
    def _add_entity_nodes_and_edges(
        self,
        paper_id: str,
        entities: Dict[str, List[Tuple[str, float]]]
    ):
        """Add entity nodes and edges with confidence scores"""
        
        # Authors
        for author, confidence in entities.get("authors", []):
            author_id = f"author_{author.replace(' ', '_').replace('.', '_')}"
            if not self.graph.has_node(author_id):
                self.graph.add_node(
                    author_id,
                    node_type="author",
                    name=author,
                    confidence=confidence
                )
            self.graph.add_edge(
                paper_id, author_id,
                relation="authored_by",
                weight=confidence,
                confidence=confidence
            )
        
        # Categories
        for category, confidence in entities.get("categories", []):
            cat_id = f"category_{category}"
            if not self.graph.has_node(cat_id):
                self.graph.add_node(
                    cat_id,
                    node_type="category",
                    name=category,
                    confidence=confidence
                )
            self.graph.add_edge(
                paper_id, cat_id,
                relation="belongs_to",
                weight=confidence,
                confidence=confidence
            )
        
        # Concepts (with confidence)
        for concept, confidence in entities.get("concepts", []):
            concept_id = f"concept_{concept.replace(' ', '_').replace('-', '_')}"
            if not self.graph.has_node(concept_id):
                self.graph.add_node(
                    concept_id,
                    node_type="concept",
                    name=concept,
                    confidence=confidence
                )
            self.graph.add_edge(
                paper_id, concept_id,
                relation="discusses",
                weight=confidence,
                confidence=confidence
            )
        
        # Keywords (top keywords only)
        for keyword, confidence in entities.get("keywords", [])[:5]:
            keyword_id = f"keyword_{keyword.replace(' ', '_')}"
            if not self.graph.has_node(keyword_id):
                self.graph.add_node(
                    keyword_id,
                    node_type="keyword",
                    name=keyword,
                    confidence=confidence
                )
            self.graph.add_edge(
                paper_id, keyword_id,
                relation="contains",
                weight=confidence,
                confidence=confidence
            )
        
        # Methods
        for method, confidence in entities.get("methods", [])[:3]:
            method_id = f"method_{method.replace(' ', '_')}"
            if not self.graph.has_node(method_id):
                self.graph.add_node(
                    method_id,
                    node_type="method",
                    name=method,
                    confidence=confidence
                )
            self.graph.add_edge(
                paper_id, method_id,
                relation="uses_method",
                weight=confidence,
                confidence=confidence
            )
    
    def _add_weighted_similarity_edges(
        self,
        papers: List[Dict],
        paper_entities: Dict[str, Dict]
    ):
        """
        Add similarity edges with weighted scores
        
        Uses multiple signals:
        - Shared authors (weighted by number)
        - Shared concepts (weighted by confidence)
        - Shared methods
        - Text similarity (optional)
        """
        paper_ids = list(paper_entities.keys())
        
        for i, paper_id1 in enumerate(paper_ids):
            for paper_id2 in paper_ids[i+1:]:
                entities1 = paper_entities[paper_id1]
                entities2 = paper_entities[paper_id2]
                
                # Compute similarity score
                similarity_score = self._compute_paper_similarity(
                    entities1, entities2
                )
                
                if similarity_score >= self.min_edge_weight:
                    # Determine relation type based on what's shared
                    relation_type = self._determine_relation_type(
                        entities1, entities2
                    )
                    
                    self.graph.add_edge(
                        paper_id1, paper_id2,
                        relation=relation_type,
                        weight=similarity_score,
                        confidence=similarity_score
                    )
    
    def _compute_paper_similarity(
        self,
        entities1: Dict,
        entities2: Dict
    ) -> float:
        """
        Compute weighted similarity between two papers
        
        Returns:
            Similarity score between 0 and 1
        """
        scores = []
        
        # Author similarity (binary: shared or not, weighted by count)
        authors1 = {e[0] for e in entities1.get("authors", [])}
        authors2 = {e[0] for e in entities2.get("authors", [])}
        shared_authors = authors1 & authors2
        if shared_authors:
            # Normalize by max authors
            max_authors = max(len(authors1), len(authors2), 1)
            author_score = len(shared_authors) / max_authors
            scores.append(("author", author_score * 0.3))  # 30% weight
        
        # Concept similarity (weighted by confidence)
        concepts1 = {e[0]: e[1] for e in entities1.get("concepts", [])}
        concepts2 = {e[0]: e[1] for e in entities2.get("concepts", [])}
        shared_concepts = set(concepts1.keys()) & set(concepts2.keys())
        if shared_concepts:
            # Average confidence of shared concepts
            concept_confidences = [
                (concepts1[c] + concepts2[c]) / 2
                for c in shared_concepts
            ]
            concept_score = np.mean(concept_confidences) if concept_confidences else 0
            scores.append(("concept", concept_score * 0.5))  # 50% weight
        
        # Method similarity
        methods1 = {e[0] for e in entities1.get("methods", [])}
        methods2 = {e[0] for e in entities2.get("methods", [])}
        shared_methods = methods1 & methods2
        if shared_methods:
            method_score = len(shared_methods) / max(len(methods1), len(methods2), 1)
            scores.append(("method", method_score * 0.2))  # 20% weight
        
        # Return weighted sum
        if scores:
            return sum(score for _, score in scores)
        return 0.0
    
    def _determine_relation_type(
        self,
        entities1: Dict,
        entities2: Dict
    ) -> str:
        """Determine the primary relation type between papers"""
        authors1 = {e[0] for e in entities1.get("authors", [])}
        authors2 = {e[0] for e in entities2.get("authors", [])}
        if authors1 & authors2:
            return "similar_author"
        
        concepts1 = {e[0] for e in entities1.get("concepts", [])}
        concepts2 = {e[0] for e in entities2.get("concepts", [])}
        if concepts1 & concepts2:
            return "similar_concept"
        
        return "similar"
    
    def _prune_graph(self):
        """
        Prune graph by removing low-confidence edges
        
        Strategy:
        1. Remove edges below weight threshold
        2. Remove isolated nodes (optional)
        3. Keep graph connected components
        """
        edges_to_remove = []
        
        for source, target, data in self.graph.edges(data=True):
            weight = data.get('weight', 0)
            if weight < self.min_edge_weight:
                edges_to_remove.append((source, target))
        
        self.graph.remove_edges_from(edges_to_remove)
        
        # Remove isolated nodes (nodes with no edges)
        isolated = list(nx.isolates(self.graph))
        self.graph.remove_nodes_from(isolated)
        
        print(f"Pruned {len(edges_to_remove)} edges and {len(isolated)} isolated nodes")
    
    def get_paper_neighbors(
        self,
        paper_id: str,
        relation_type: str = None,
        min_confidence: float = None
    ) -> List[Dict]:
        """
        Get neighboring nodes with confidence filtering
        
        Args:
            paper_id: Paper ID
            relation_type: Filter by relation type
            min_confidence: Minimum confidence threshold
            
        Returns:
            List of neighbor dictionaries with confidence scores
        """
        neighbors = []
        if not self.graph.has_node(paper_id):
            return neighbors
        
        min_conf = min_confidence or self.min_entity_confidence
        
        for neighbor_id in self.graph.neighbors(paper_id):
            neighbor_data = self.graph.nodes[neighbor_id]
            edges = self.graph[paper_id][neighbor_id]
            
            for edge_key, edge_data in edges.items():
                if relation_type and edge_data.get('relation') != relation_type:
                    continue
                
                confidence = edge_data.get('confidence', edge_data.get('weight', 0))
                if confidence < min_conf:
                    continue
                
                neighbors.append({
                    "id": neighbor_id,
                    "type": neighbor_data.get('node_type', 'unknown'),
                    "data": neighbor_data,
                    "relation": edge_data.get('relation', 'unknown'),
                    "confidence": confidence,
                    "weight": edge_data.get('weight', 0)
                })
                break
        
        # Sort by confidence
        neighbors.sort(key=lambda x: x.get('confidence', 0), reverse=True)
        
        return neighbors
    
    def find_path(
        self,
        source_id: str,
        target_id: str,
        max_depth: int = 3,
        min_confidence: float = None
    ) -> List[List[Dict]]:
        """
        Find paths between nodes with confidence-weighted scoring
        
        Returns paths with confidence scores
        """
        if not (self.graph.has_node(source_id) and self.graph.has_node(target_id)):
            return []
        
        min_conf = min_confidence or self.min_entity_confidence
        
        try:
            # Find all simple paths
            paths = list(nx.all_simple_paths(
                self.graph.to_undirected(),
                source_id,
                target_id,
                cutoff=max_depth
            ))
            
            # Score paths by average confidence
            scored_paths = []
            for path in paths[:20]:  # Limit to 20 paths
                path_confidence = self._compute_path_confidence(path)
                if path_confidence >= min_conf:
                    # Format path with node information
                    formatted_path = []
                    for node_id in path:
                        node_data = self.graph.nodes[node_id]
                        formatted_path.append({
                            "id": node_id,
                            "type": node_data.get('node_type', 'unknown'),
                            "title": node_data.get('title', node_data.get('name', 'Unknown')),
                            "confidence": node_data.get('confidence', 1.0)
                        })
                    scored_paths.append((formatted_path, path_confidence))
            
            # Sort by confidence and return top paths
            scored_paths.sort(key=lambda x: x[1], reverse=True)
            return [path for path, _ in scored_paths[:10]]
            
        except Exception as e:
            print(f"Error finding path: {e}")
            return []
    
    def _compute_path_confidence(self, path: List[str]) -> float:
        """Compute average confidence along a path"""
        if len(path) < 2:
            return 0.0
        
        confidences = []
        for i in range(len(path) - 1):
            source, target = path[i], path[i+1]
            if self.graph.has_edge(source, target):
                edge_data = self.graph[source][target]
                # Get confidence from first edge
                for edge_key, data in edge_data.items():
                    conf = data.get('confidence', data.get('weight', 0))
                    confidences.append(conf)
                    break
        
        return np.mean(confidences) if confidences else 0.0
    
    # Inherit other methods from original KnowledgeGraphBuilder
    def get_subgraph(self, paper_ids: List[str], depth: int = 1) -> nx.MultiDiGraph:
        """Get subgraph around specific papers"""
        nodes_to_include = set(paper_ids)
        current_nodes = set(paper_ids)
        
        for _ in range(depth):
            next_nodes = set()
            for node in current_nodes:
                if self.graph.has_node(node):
                    next_nodes.update(self.graph.neighbors(node))
            nodes_to_include.update(next_nodes)
            current_nodes = next_nodes
        
        return self.graph.subgraph(nodes_to_include)
    
    def save_graph(self, filepath: str = "data/knowledge_graph.json"):
        """Save graph with confidence scores"""
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        
        graph_data = {
            "nodes": [
                {
                    "id": node_id,
                    **data
                }
                for node_id, data in self.graph.nodes(data=True)
            ],
            "edges": [
                {
                    "source": source,
                    "target": target,
                    "relation": data.get('relation', 'unknown'),
                    "weight": data.get('weight', 1),
                    "confidence": data.get('confidence', data.get('weight', 1))
                }
                for source, target, data in self.graph.edges(data=True)
            ]
        }
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(graph_data, f, indent=2, ensure_ascii=False)
        
        print(f"Graph saved to {filepath}")
    
    def load_graph(self, filepath: str = "data/knowledge_graph.json"):
        """Load graph from file"""
        if not os.path.exists(filepath):
            return False
        
        with open(filepath, 'r', encoding='utf-8') as f:
            graph_data = json.load(f)
        
        self.graph = nx.MultiDiGraph()
        
        for node in graph_data.get("nodes", []):
            node_id = node.pop("id")
            self.graph.add_node(node_id, **node)
        
        for edge in graph_data.get("edges", []):
            self.graph.add_edge(
                edge["source"],
                edge["target"],
                relation=edge.get("relation", "unknown"),
                weight=edge.get("weight", 1),
                confidence=edge.get("confidence", edge.get("weight", 1))
            )
        
        print(f"Graph loaded from {filepath}")
        return True
    
    def get_statistics(self) -> Dict:
        """Get graph statistics"""
        node_types = defaultdict(int)
        for _, data in self.graph.nodes(data=True):
            node_types[data.get('node_type', 'unknown')] += 1
        
        return {
            "nodes": self.graph.number_of_nodes(),
            "edges": self.graph.number_of_edges(),
            "node_types": dict(node_types),
            "is_connected": nx.is_weakly_connected(self.graph),
            "num_components": nx.number_weakly_connected_components(self.graph),
            "avg_degree": sum(dict(self.graph.degree()).values()) / self.graph.number_of_nodes() if self.graph.number_of_nodes() > 0 else 0
        }

