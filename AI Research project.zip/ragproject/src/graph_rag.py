"""
Graph RAG Pipeline - Traverses knowledge graph for enhanced retrieval
"""
from typing import List, Dict, Set
import networkx as nx
from src.graph_builder import KnowledgeGraphBuilder
from src.rag_pipeline import RAGPipeline


class GraphRAGPipeline:
    """Graph RAG combines graph traversal with RAG"""
    
    def __init__(self, graph_builder: KnowledgeGraphBuilder, rag_pipeline: RAGPipeline):
        """
        Initialize Graph RAG pipeline
        
        Args:
            graph_builder: KnowledgeGraphBuilder instance
            rag_pipeline: RAGPipeline instance
        """
        self.graph_builder = graph_builder
        self.rag_pipeline = rag_pipeline
        
    def graph_retrieve(self, query: str, top_k: int = 5, graph_expansion: int = 1) -> List[Dict]:
        """
        Retrieve using both vector search and graph traversal
        
        Args:
            query: Search query
            top_k: Number of initial results
            graph_expansion: Depth of graph expansion
            
        Returns:
            Enhanced retrieval results with graph context
        """
        # Step 1: Initial RAG retrieval
        initial_results = self.rag_pipeline.retrieve(query, top_k=top_k)
        
        if not initial_results:
            return []
        
        # Step 2: Extract paper IDs from initial results
        paper_ids = set()
        for result in initial_results:
            paper_id = result['metadata'].get('paper_id')
            if paper_id:
                paper_ids.add(paper_id)
        
        # Step 3: Expand via graph traversal
        expanded_papers = set(paper_ids)
        for paper_id in paper_ids:
            # Get neighbors
            neighbors = self.graph_builder.get_paper_neighbors(paper_id)
            for neighbor in neighbors:
                if neighbor['type'] == 'paper':
                    expanded_papers.add(neighbor['id'])
            
            # Get subgraph for context
            if graph_expansion > 1:
                subgraph = self.graph_builder.get_subgraph([paper_id], depth=graph_expansion)
                for node in subgraph.nodes():
                    if self.graph_builder.graph.nodes[node].get('node_type') == 'paper':
                        expanded_papers.add(node)
        
        # Step 4: Retrieve additional context from expanded papers
        enhanced_results = initial_results.copy()
        
        # Add graph context to each result
        for result in enhanced_results:
            paper_id = result['metadata'].get('paper_id')
            if paper_id:
                # Get graph neighbors
                neighbors = self.graph_builder.get_paper_neighbors(paper_id)
                result['graph_context'] = {
                    "neighbors": neighbors,
                    "related_papers": [n for n in neighbors if n['type'] == 'paper'],
                    "concepts": [n for n in neighbors if n['type'] == 'concept'],
                    "authors": [n for n in neighbors if n['type'] == 'author']
                }
        
        return enhanced_results
    
    def find_related_papers(self, paper_id: str, relation_type: str = None, limit: int = 10) -> List[Dict]:
        """
        Find papers related to a given paper through graph
        
        Args:
            paper_id: Paper ID
            relation_type: Type of relation (similar_author, similar_concept, etc.)
            limit: Maximum number of results
            
        Returns:
            List of related papers
        """
        neighbors = self.graph_builder.get_paper_neighbors(paper_id, relation_type=relation_type)
        related_papers = [n for n in neighbors if n['type'] == 'paper']
        return related_papers[:limit]
    
    def trace_connection(self, source_paper_id: str, target_paper_id: str) -> Dict:
        """
        Trace connection path between two papers
        
        Args:
            source_paper_id: Source paper ID
            target_paper_id: Target paper ID
            
        Returns:
            Connection path information
        """
        paths = self.graph_builder.find_path(source_paper_id, target_paper_id)
        
        if not paths:
            return {
                "connected": False,
                "paths": [],
                "message": "No path found between papers"
            }
        
        # Format paths with node information
        formatted_paths = []
        for path in paths:
            formatted_path = []
            for node_id in path:
                node_data = self.graph_builder.graph.nodes[node_id]
                formatted_path.append({
                    "id": node_id,
                    "type": node_data.get('node_type', 'unknown'),
                    "title": node_data.get('title', node_data.get('name', 'Unknown'))
                })
            formatted_paths.append(formatted_path)
        
        return {
            "connected": True,
            "paths": formatted_paths,
            "shortest_path_length": len(paths[0]) if paths else 0
        }
    
    def get_paper_recommendations(self, paper_id: str, top_k: int = 5) -> List[Dict]:
        """
        Get paper recommendations based on graph structure
        
        Args:
            paper_id: Paper ID
            top_k: Number of recommendations
            
        Returns:
            List of recommended papers
        """
        # Get neighbors
        neighbors = self.graph_builder.get_paper_neighbors(paper_id)
        
        # Filter papers and score by relation types
        paper_scores = {}
        for neighbor in neighbors:
            if neighbor['type'] == 'paper':
                neighbor_paper_id = neighbor['id']
                relation = neighbor['relation']
                
                # Score based on relation type
                score = {
                    'similar_author': 3,
                    'similar_concept': 2,
                    'discusses': 1
                }.get(relation, 1)
                
                if neighbor_paper_id not in paper_scores:
                    paper_scores[neighbor_paper_id] = {
                        "paper": neighbor,
                        "score": 0
                    }
                paper_scores[neighbor_paper_id]["score"] += score
        
        # Sort by score and return top_k
        sorted_papers = sorted(
            paper_scores.values(),
            key=lambda x: x['score'],
            reverse=True
        )
        
        return [item['paper'] for item in sorted_papers[:top_k]]
    
    def format_graph_context(self, results: List[Dict]) -> str:
        """Format graph context for LLM prompt"""
        context_parts = []
        
        for result in results:
            text = result['text']
            metadata = result['metadata']
            graph_context = result.get('graph_context', {})
            
            context_parts.append(f"Paper: {metadata.get('title', 'Unknown')}")
            context_parts.append(f"Content: {text}\n")
            
            # Add graph context
            if graph_context.get('related_papers'):
                related = [p['data'].get('title', p['id']) for p in graph_context['related_papers'][:3]]
                context_parts.append(f"Related papers: {', '.join(related)}")
            
            if graph_context.get('concepts'):
                concepts = [c['data'].get('name', c['id']) for c in graph_context['concepts'][:3]]
                context_parts.append(f"Key concepts: {', '.join(concepts)}")
            
            context_parts.append("")
        
        return "\n".join(context_parts)

