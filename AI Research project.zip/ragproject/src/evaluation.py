"""
Evaluation Module using RAGAS metrics
"""
from typing import List, Dict
from ragas import evaluate
from ragas.metrics import (
    faithfulness,
    answer_relevancy,
    context_precision,
    context_recall
)
from datasets import Dataset
import pandas as pd


class RAGEvaluator:
    """Evaluate RAG pipeline using RAGAS metrics"""
    
    def __init__(self, rag_pipeline, graph_rag_pipeline=None):
        """
        Initialize evaluator
        
        Args:
            rag_pipeline: RAGPipeline instance
            graph_rag_pipeline: GraphRAGPipeline instance (optional)
        """
        self.rag_pipeline = rag_pipeline
        self.graph_rag_pipeline = graph_rag_pipeline
        
    def create_evaluation_dataset(
        self,
        questions: List[str],
        ground_truths: List[str] = None
    ) -> List[Dict]:
        """
        Create evaluation dataset
        
        Args:
            questions: List of questions
            ground_truths: List of ground truth answers (optional)
            
        Returns:
            List of evaluation examples
        """
        examples = []
        
        for i, question in enumerate(questions):
            # Retrieve context
            retrieved_chunks = self.rag_pipeline.retrieve(question, top_k=5)
            context = [chunk['text'] for chunk in retrieved_chunks]
            
            # Get answer (would normally use LLM, here we use context)
            answer = self._generate_answer_from_context(question, context)
            
            example = {
                "question": question,
                "contexts": context,
                "answer": answer
            }
            
            if ground_truths and i < len(ground_truths):
                example["ground_truth"] = ground_truths[i]
            
            examples.append(example)
        
        return examples
    
    def _generate_answer_from_context(self, question: str, contexts: List[str]) -> str:
        """Generate answer from context using LLM if available"""
        try:
            from src.llm_generator import LLMGenerator
            from src.config_loader import ConfigLoader
            
            # Try to use LLM generator
            config = ConfigLoader()
            llm_config = config.get_section('llm')
            llm = LLMGenerator(
                provider=llm_config.get('provider', 'ollama'),
                model_name=llm_config.get('model_name', 'llama3.2'),
                temperature=llm_config.get('temperature', 0.7),
                max_tokens=llm_config.get('max_tokens', 200)
            )
            
            combined_context = "\n".join(contexts[:3])
            prompt = f"""You are a helpful research assistant. Answer the question based on the following research paper excerpts.

Context from research papers:
{combined_context}

Question: {question}

Answer:"""
            
            answer = llm.generate(prompt, combined_context)
            return answer
        except Exception as e:
            # Fallback to simplified generation
            print(f"Warning: Could not use LLM for evaluation: {e}. Using simplified generation.")
            combined_context = "\n".join(contexts[:3])
            return f"Based on the research papers: {combined_context[:200]}..."
    
    def evaluate_rag(self, evaluation_dataset: List[Dict]) -> Dict:
        """
        Evaluate RAG pipeline using RAGAS
        
        Args:
            evaluation_dataset: List of evaluation examples
            
        Returns:
            Evaluation metrics dictionary
        """
        # Convert to Hugging Face Dataset
        df = pd.DataFrame(evaluation_dataset)
        
        # Ensure required columns
        required_cols = ["question", "contexts", "answer"]
        if not all(col in df.columns for col in required_cols):
            raise ValueError(f"Dataset must contain columns: {required_cols}")
        
        dataset = Dataset.from_pandas(df)
        
        # Evaluate
        try:
            result = evaluate(
                dataset=dataset,
                metrics=[
                    faithfulness,
                    answer_relevancy,
                    context_precision,
                    context_recall
                ]
            )
            
            # Convert to dictionary
            metrics_dict = {
                "faithfulness": result.get("faithfulness", 0.0),
                "answer_relevancy": result.get("answer_relevancy", 0.0),
                "context_precision": result.get("context_precision", 0.0),
                "context_recall": result.get("context_recall", 0.0)
            }
            
            # Calculate average
            metrics_dict["average_score"] = sum(metrics_dict.values()) / len(metrics_dict)
            
            return metrics_dict
            
        except Exception as e:
            print(f"Evaluation error: {e}")
            return {
                "faithfulness": 0.0,
                "answer_relevancy": 0.0,
                "context_precision": 0.0,
                "context_recall": 0.0,
                "average_score": 0.0,
                "error": str(e)
            }
    
    def evaluate_graph_rag(
        self,
        questions: List[str],
        ground_truths: List[str] = None
    ) -> Dict:
        """
        Evaluate Graph RAG pipeline
        
        Args:
            questions: List of questions
            ground_truths: List of ground truth answers (optional)
            
        Returns:
            Evaluation metrics dictionary
        """
        if not self.graph_rag_pipeline:
            return {"error": "Graph RAG pipeline not available"}
        
        examples = []
        
        for i, question in enumerate(questions):
            # Use Graph RAG retrieval
            retrieved_chunks = self.graph_rag_pipeline.graph_retrieve(question, top_k=5)
            context = [chunk['text'] for chunk in retrieved_chunks]
            
            # Get answer
            answer = self._generate_answer_from_context(question, context)
            
            example = {
                "question": question,
                "contexts": context,
                "answer": answer
            }
            
            if ground_truths and i < len(ground_truths):
                example["ground_truth"] = ground_truths[i]
            
            examples.append(example)
        
        return self.evaluate_rag(examples)
    
    def compare_rag_vs_graph_rag(
        self,
        questions: List[str],
        ground_truths: List[str] = None
    ) -> Dict:
        """
        Compare RAG vs Graph RAG performance
        
        Args:
            questions: List of questions
            ground_truths: List of ground truth answers (optional)
            
        Returns:
            Comparison results
        """
        # Evaluate standard RAG
        rag_dataset = self.create_evaluation_dataset(questions, ground_truths)
        rag_metrics = self.evaluate_rag(rag_dataset)
        
        # Evaluate Graph RAG
        graph_rag_metrics = {}
        if self.graph_rag_pipeline:
            graph_rag_metrics = self.evaluate_graph_rag(questions, ground_truths)
        
        return {
            "rag_metrics": rag_metrics,
            "graph_rag_metrics": graph_rag_metrics,
            "improvement": {
                metric: graph_rag_metrics.get(metric, 0) - rag_metrics.get(metric, 0)
                for metric in ["faithfulness", "answer_relevancy", "context_precision", "context_recall", "average_score"]
            }
        }
    
    def get_retrieval_stats(self, questions: List[str]) -> Dict:
        """
        Get retrieval statistics
        
        Args:
            questions: List of questions
            
        Returns:
            Statistics dictionary
        """
        stats = {
            "total_questions": len(questions),
            "avg_chunks_per_query": 0,
            "avg_chunk_length": 0,
            "total_chunks_retrieved": 0
        }
        
        all_chunks = []
        for question in questions:
            chunks = self.rag_pipeline.retrieve(question, top_k=5)
            all_chunks.extend(chunks)
            stats["total_chunks_retrieved"] += len(chunks)
        
        if all_chunks:
            stats["avg_chunks_per_query"] = stats["total_chunks_retrieved"] / len(questions)
            chunk_lengths = [len(chunk['text']) for chunk in all_chunks]
            stats["avg_chunk_length"] = sum(chunk_lengths) / len(chunk_lengths)
        
        return stats

