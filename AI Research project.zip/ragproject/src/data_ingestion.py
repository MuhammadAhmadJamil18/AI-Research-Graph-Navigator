"""
Data ingestion module for fetching and processing ArXiv papers
"""

import json
import os
from typing import Dict, List

import arxiv
import pandas as pd


class ArXivIngester:
    """Fetches and processes ArXiv papers"""

    def __init__(self, data_dir: str = "data") -> None:
        """
        Initialize ArXiv ingester with data directory.

        Args:
            data_dir: Directory path for storing fetched papers.
                Default: "data"

        Returns:
            None
        """
        self.data_dir = data_dir
        os.makedirs(data_dir, exist_ok=True)

    def fetch_papers(
        self,
        query: str = "cat:cs.AI OR cat:cs.LG OR cat:cs.CL",
        max_results: int = 50,
        sort_by: str = "submittedDate",
        sort_order: str = "descending",
    ) -> List[Dict]:
        """
        Fetch research papers from ArXiv API.

        Searches ArXiv for papers matching the query, downloads metadata,
        and returns a list of paper dictionaries with all relevant information.

        Args:
            query: ArXiv search query string. Supports ArXiv query syntax.
                Default: "cat:cs.AI OR cat:cs.LG OR cat:cs.CL"
            max_results: Maximum number of papers to fetch.
                Default: 50
            sort_by: Sort criteria. Options: "submittedDate", "relevance", "lastUpdatedDate".
                Default: "submittedDate"
            sort_order: Sort order. Options: "ascending", "descending".
                Default: "descending"

        Returns:
            List of paper dictionaries, each containing:
                - 'id': ArXiv paper ID
                - 'title': Paper title
                - 'authors': List of author names
                - 'summary': Paper abstract
                - 'published': Publication date
                - 'categories': List of ArXiv categories
                - 'url': ArXiv URL
                - 'pdf_url': PDF download URL

        Raises:
            Exception: If ArXiv API request fails or network error occurs

        Example:
            >>> ingester = ArXivIngester()
            >>> papers = ingester.fetch_papers(
            ...     query="cat:cs.AI",
            ...     max_results=10
            ... )
            >>> print(f"Fetched {len(papers)} papers")
        """
        print(f"Fetching {max_results} papers from ArXiv...")

        client = arxiv.Client()
        search = arxiv.Search(
            query=query,
            max_results=max_results,
            sort_by=(
                arxiv.SortCriterion.SubmittedDate
                if sort_by == "submittedDate"
                else arxiv.SortCriterion.Relevance
            ),
            sort_order=(
                arxiv.SortOrder.Descending
                if sort_order == "descending"
                else arxiv.SortOrder.Ascending
            ),
        )

        papers = []
        for paper in client.results(search):
            paper_dict = {
                "id": paper.entry_id.split("/")[-1],
                "title": paper.title,
                "authors": [str(author) for author in paper.authors],
                "summary": paper.summary,
                "published": paper.published.isoformat() if paper.published else None,
                "updated": paper.updated.isoformat() if paper.updated else None,
                "categories": paper.categories,
                "pdf_url": paper.pdf_url,
                "primary_category": paper.primary_category,
                "url": paper.entry_id,
            }
            papers.append(paper_dict)

        print(f"Fetched {len(papers)} papers")
        return papers

    def save_papers(self, papers: List[Dict], filename: str = "papers.json") -> None:
        """
        Save papers to a JSON file.

        Saves the list of paper dictionaries to a JSON file in the data directory
        with pretty formatting (indented, UTF-8 encoded).

        Args:
            papers: List of paper dictionaries to save
            filename: Name of the JSON file. Default: "papers.json"

        Returns:
            None

        Raises:
            IOError: If file writing fails
            PermissionError: If directory is not writable

        Example:
            >>> papers = [{'id': '123', 'title': 'Test'}]
            >>> ingester.save_papers(papers, 'my_papers.json')
        """
        filepath = os.path.join(self.data_dir, filename)
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(papers, f, indent=2, ensure_ascii=False)
        print(f"Saved {len(papers)} papers to {filepath}")

    def load_papers(self, filename: str = "papers.json") -> List[Dict]:
        """
        Load papers from a JSON file.

        Loads paper dictionaries from a JSON file in the data directory.
        Returns an empty list if the file doesn't exist.

        Args:
            filename: Name of the JSON file to load. Default: "papers.json"

        Returns:
            List of paper dictionaries, or empty list if file doesn't exist

        Raises:
            json.JSONDecodeError: If file contains invalid JSON
            IOError: If file reading fails

        Example:
            >>> papers = ingester.load_papers('papers.json')
            >>> print(f"Loaded {len(papers)} papers")
        """
        filepath = os.path.join(self.data_dir, filename)
        if os.path.exists(filepath):
            with open(filepath, "r", encoding="utf-8") as f:
                papers = json.load(f)
            print(f"Loaded {len(papers)} papers from {filepath}")
            return papers
        return []

    def chunk_paper(self, paper: Dict, chunk_size: int = 500, overlap: int = 50) -> List[Dict]:
        """
        Split paper into chunks for embedding

        Args:
            paper: Paper dictionary
            chunk_size: Number of characters per chunk
            overlap: Overlap between chunks

        Returns:
            List of chunk dictionaries
        """
        text = f"{paper['title']}\n\n{paper['summary']}"
        chunks = []

        start = 0
        while start < len(text):
            end = start + chunk_size
            chunk_text = text[start:end]

            chunk = {
                "paper_id": paper["id"],
                "title": paper["title"],
                "chunk_text": chunk_text,
                "chunk_index": len(chunks),
                "start_pos": start,
                "end_pos": end,
            }
            chunks.append(chunk)

            start = end - overlap

        return chunks

    def prepare_dataset(self, papers: List[Dict]) -> pd.DataFrame:
        """Convert papers to DataFrame for easier processing"""
        return pd.DataFrame(papers)
