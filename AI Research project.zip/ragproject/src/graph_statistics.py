"""
Professional Graph Statistics Module
PowerBI-style analytics and visualizations
"""
import networkx as nx
import pandas as pd
import numpy as np
from typing import Dict, List, Tuple
from collections import defaultdict, Counter


class GraphStatistics:
    """Generate comprehensive, professional graph statistics"""
    
    def __init__(self, graph: nx.MultiDiGraph):
        """
        Initialize statistics generator
        
        Args:
            graph: NetworkX graph
        """
        self.graph = graph
        self._stats_cache = None
    
    def get_comprehensive_stats(self) -> Dict:
        """
        Get comprehensive graph statistics
        
        Returns:
            Dictionary with all statistics
        """
        if self.graph.number_of_nodes() == 0:
            return self._get_empty_stats()
        
        # Basic metrics
        basic = self._get_basic_metrics()
        
        # Node analysis
        node_analysis = self._analyze_nodes()
        
        # Edge analysis
        edge_analysis = self._analyze_edges()
        
        # Network metrics
        network_metrics = self._get_network_metrics()
        
        # Top entities
        top_entities = self._get_top_entities()
        
        # Connectivity
        connectivity = self._analyze_connectivity()
        
        return {
            **basic,
            **node_analysis,
            **edge_analysis,
            **network_metrics,
            **top_entities,
            **connectivity
        }
    
    def _get_empty_stats(self) -> Dict:
        """Return empty stats structure"""
        return {
            "total_nodes": 0,
            "total_edges": 0,
            "node_types": {},
            "edge_types": {},
            "avg_degree": 0,
            "density": 0,
            "is_connected": False,
            "num_components": 0,
            "avg_clustering": 0,
            "diameter": 0,
            "avg_path_length": 0
        }
    
    def _get_basic_metrics(self) -> Dict:
        """Get basic graph metrics"""
        return {
            "total_nodes": self.graph.number_of_nodes(),
            "total_edges": self.graph.number_of_edges(),
            "density": nx.density(self.graph.to_undirected()) if self.graph.number_of_nodes() > 1 else 0,
            "avg_degree": sum(dict(self.graph.degree()).values()) / self.graph.number_of_nodes() if self.graph.number_of_nodes() > 0 else 0
        }
    
    def _analyze_nodes(self) -> Dict:
        """Analyze node types and distribution"""
        node_types = defaultdict(int)
        node_data_list = []
        
        for node_id, data in self.graph.nodes(data=True):
            node_type = data.get('node_type', 'unknown')
            node_types[node_type] += 1
            
            node_data_list.append({
                "id": node_id,
                "type": node_type,
                "degree": self.graph.degree(node_id),
                "in_degree": self.graph.in_degree(node_id),
                "out_degree": self.graph.out_degree(node_id)
            })
        
        # Calculate type-specific metrics
        type_metrics = {}
        for node_type, count in node_types.items():
            type_nodes = [n for n in node_data_list if n['type'] == node_type]
            if type_nodes:
                type_metrics[f"{node_type}_avg_degree"] = np.mean([n['degree'] for n in type_nodes])
                type_metrics[f"{node_type}_max_degree"] = max([n['degree'] for n in type_nodes])
        
        return {
            "node_types": dict(node_types),
            "node_data": node_data_list,
            **type_metrics
        }
    
    def _analyze_edges(self) -> Dict:
        """Analyze edge types and relationships"""
        edge_types = Counter()
        edge_weights = []
        relation_types = Counter()
        
        for source, target, data in self.graph.edges(data=True):
            relation = data.get('relation', 'unknown')
            weight = data.get('weight', 1)
            confidence = data.get('confidence', weight)
            
            edge_types[relation] += 1
            relation_types[relation] += 1
            edge_weights.append(weight)
        
        return {
            "edge_types": dict(edge_types),
            "relation_types": dict(relation_types),
            "avg_edge_weight": np.mean(edge_weights) if edge_weights else 0,
            "max_edge_weight": max(edge_weights) if edge_weights else 0,
            "min_edge_weight": min(edge_weights) if edge_weights else 0,
            "total_edge_weight": sum(edge_weights)
        }
    
    def _get_network_metrics(self) -> Dict:
        """Get advanced network metrics"""
        if self.graph.number_of_nodes() == 0:
            return {}
        
        # Convert to undirected for some metrics
        undirected = self.graph.to_undirected()
        
        metrics = {}
        
        # Clustering coefficient
        try:
            clustering = nx.clustering(undirected)
            metrics["avg_clustering"] = np.mean(list(clustering.values())) if clustering else 0
        except:
            metrics["avg_clustering"] = 0
        
        # Centrality measures (sample for large graphs)
        if self.graph.number_of_nodes() <= 1000:
            try:
                degree_centrality = nx.degree_centrality(undirected)
                metrics["avg_degree_centrality"] = np.mean(list(degree_centrality.values()))
                
                betweenness = nx.betweenness_centrality(undirected, k=min(100, self.graph.number_of_nodes()))
                metrics["avg_betweenness_centrality"] = np.mean(list(betweenness.values()))
            except:
                pass
        
        # Path metrics (for connected components)
        try:
            if nx.is_connected(undirected):
                metrics["diameter"] = nx.diameter(undirected)
                metrics["avg_path_length"] = nx.average_shortest_path_length(undirected)
            else:
                metrics["diameter"] = 0
                metrics["avg_path_length"] = 0
        except:
            metrics["diameter"] = 0
            metrics["avg_path_length"] = 0
        
        return metrics
    
    def _get_top_entities(self) -> Dict:
        """Get top entities by various metrics"""
        # Top nodes by degree
        degrees = dict(self.graph.degree())
        top_nodes_by_degree = sorted(degrees.items(), key=lambda x: x[1], reverse=True)[:10]
        
        # Top node types
        node_types = defaultdict(int)
        for _, data in self.graph.nodes(data=True):
            node_types[data.get('node_type', 'unknown')] += 1
        top_node_types = sorted(node_types.items(), key=lambda x: x[1], reverse=True)
        
        # Top relations
        relations = Counter()
        for _, _, data in self.graph.edges(data=True):
            relations[data.get('relation', 'unknown')] += 1
        top_relations = sorted(relations.items(), key=lambda x: x[1], reverse=True)[:10]
        
        return {
            "top_nodes_by_degree": top_nodes_by_degree,
            "top_node_types": top_node_types,
            "top_relations": top_relations
        }
    
    def _analyze_connectivity(self) -> Dict:
        """Analyze graph connectivity"""
        undirected = self.graph.to_undirected()
        
        is_connected = nx.is_connected(undirected) if self.graph.number_of_nodes() > 0 else False
        num_components = nx.number_connected_components(undirected) if self.graph.number_of_nodes() > 0 else 0
        
        # Component sizes
        if num_components > 0:
            components = list(nx.connected_components(undirected))
            component_sizes = [len(c) for c in components]
            largest_component_size = max(component_sizes) if component_sizes else 0
        else:
            component_sizes = []
            largest_component_size = 0
        
        return {
            "is_connected": is_connected,
            "num_components": num_components,
            "largest_component_size": largest_component_size,
            "component_sizes": component_sizes
        }
    
    def get_visualization_data(self) -> Dict:
        """Get data formatted for visualizations"""
        stats = self.get_comprehensive_stats()
        
        # Node type distribution
        node_type_df = pd.DataFrame([
            {"Type": k, "Count": v}
            for k, v in stats.get("node_types", {}).items()
        ])
        
        # Edge type distribution
        edge_type_df = pd.DataFrame([
            {"Relation": k, "Count": v}
            for k, v in stats.get("relation_types", {}).items()
        ])
        
        # Degree distribution
        node_data = stats.get("node_data", [])
        if node_data:
            degree_df = pd.DataFrame(node_data)
        else:
            degree_df = pd.DataFrame()
        
        return {
            "node_type_distribution": node_type_df,
            "edge_type_distribution": edge_type_df,
            "degree_distribution": degree_df,
            "stats": stats
        }

