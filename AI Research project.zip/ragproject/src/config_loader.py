"""
Configuration loader for the RAG project
Loads and validates config.yaml settings
"""
import yaml
import os
from typing import Dict, Any
from pathlib import Path


class ConfigLoader:
    """Load and manage configuration from config.yaml"""
    
    def __init__(self, config_path: str = "config.yaml"):
        """
        Initialize config loader
        
        Args:
            config_path: Path to config.yaml file
        """
        self.config_path = config_path
        self.config = self._load_config()
    
    def _load_config(self) -> Dict[str, Any]:
        """Load configuration from YAML file"""
        if not os.path.exists(self.config_path):
            print(f"Warning: {self.config_path} not found. Using defaults.")
            return self._get_default_config()
        
        try:
            with open(self.config_path, 'r', encoding='utf-8') as f:
                config = yaml.safe_load(f) or {}
            # Merge with defaults to ensure all keys exist
            default_config = self._get_default_config()
            return self._merge_configs(default_config, config)
        except Exception as e:
            print(f"Error loading config: {e}. Using defaults.")
            return self._get_default_config()
    
    def _get_default_config(self) -> Dict[str, Any]:
        """Get default configuration"""
        return {
            "data": {
                "data_dir": "data",
                "papers_file": "papers.json",
                "graph_file": "knowledge_graph.json",
                "max_papers": 50
            },
            "rag": {
                "embedding_model": "all-MiniLM-L6-v2",
                "chroma_dir": "chroma_db",
                "collection_name": "research_papers",
                "chunk_size": 500,
                "chunk_overlap": 50,
                "top_k": 5
            },
            "graph": {
                "max_keywords_per_paper": 5,
                "similarity_threshold": 0.5,
                "use_improved_builder": True,  # Use improved builder by default
                "min_entity_confidence": 0.5,
                "min_edge_weight": 0.3,
                "use_pruning": True
            },
            "chunking": {
                "strategy": "semantic",  # "semantic" or "fixed"
                "respect_sections": True
            },
            "llm": {
                "provider": "ollama",
                "model_name": "llama3.2",
                "temperature": 0.7,
                "max_tokens": 200
            },
            "training": {
                "base_model": "microsoft/Phi-2",
                "output_dir": "models/fine-tuned",
                "num_epochs": 3,
                "batch_size": 2,
                "learning_rate": 2e-4,
                "lora_r": 16,
                "lora_alpha": 32
            },
            "evaluation": {
                "default_questions": [
                    "What are the main approaches to transformer architectures?",
                    "How do large language models handle few-shot learning?",
                    "What is the difference between supervised and unsupervised learning?",
                    "How do neural networks learn from data?",
                    "What are the applications of computer vision?"
                ]
            }
        }
    
    def _merge_configs(self, default: Dict, user: Dict) -> Dict:
        """Merge user config with defaults (deep merge)"""
        result = default.copy()
        for key, value in user.items():
            if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                result[key] = self._merge_configs(result[key], value)
            else:
                result[key] = value
        return result
    
    def get(self, key_path: str, default: Any = None) -> Any:
        """
        Get config value by dot-separated path
        
        Args:
            key_path: Dot-separated path (e.g., "rag.chunk_size")
            default: Default value if not found
            
        Returns:
            Config value or default
        """
        keys = key_path.split('.')
        value = self.config
        for key in keys:
            if isinstance(value, dict) and key in value:
                value = value[key]
            else:
                return default
        return value
    
    def get_section(self, section: str) -> Dict[str, Any]:
        """
        Get entire config section
        
        Args:
            section: Section name (e.g., "rag", "graph")
            
        Returns:
            Section dictionary or empty dict
        """
        return self.config.get(section, {})
    
    def get_all(self) -> Dict[str, Any]:
        """Get entire configuration"""
        return self.config.copy()

