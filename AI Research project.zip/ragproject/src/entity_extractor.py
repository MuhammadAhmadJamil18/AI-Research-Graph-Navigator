"""
Advanced Entity Extraction using NLP methods
Replaces heuristic-based extraction with learned approaches
"""
from typing import List, Dict, Tuple
import re
from collections import Counter
try:
    import spacy
    SPACY_AVAILABLE = True
except (ImportError, Exception):
    SPACY_AVAILABLE = False
    spacy = None
from sentence_transformers import SentenceTransformer
import numpy as np


class EntityExtractor:
    """
    NLP-based entity extraction with confidence scoring
    Replaces heuristic keyword matching with proper NLP
    """
    
    def __init__(
        self,
        use_spacy: bool = True,
        embedding_model: str = "all-MiniLM-L6-v2",
        concept_threshold: float = 0.6
    ):
        """
        Initialize entity extractor
        
        Args:
            use_spacy: Whether to use spaCy for NER (if available)
            embedding_model: Model for semantic concept matching
            concept_threshold: Similarity threshold for concept matching
        """
        self.use_spacy = use_spacy
        self.concept_threshold = concept_threshold
        
        # Try to load spaCy model
        self.nlp = None
        if use_spacy and SPACY_AVAILABLE:
            try:
                self.nlp = spacy.load("en_core_web_sm")
            except (OSError, Exception):
                print("Warning: spaCy model not found or incompatible. Continuing without spaCy.")
                self.use_spacy = False
        elif use_spacy and not SPACY_AVAILABLE:
            print("Warning: spaCy not available (Python 3.14 compatibility issue). Continuing without spaCy.")
            self.use_spacy = False
        
        # Load embedding model for concept matching
        self.embedding_model = SentenceTransformer(embedding_model)
        
        # AI/ML concept embeddings (pre-computed for efficiency)
        self.concept_embeddings = self._load_concept_embeddings()
    
    def _load_concept_embeddings(self) -> Dict[str, np.ndarray]:
        """Pre-compute embeddings for known AI/ML concepts"""
        concepts = [
            "machine learning", "deep learning", "neural network", "transformer",
            "reinforcement learning", "natural language processing", "computer vision",
            "generative adversarial network", "large language model", "attention mechanism",
            "transfer learning", "few-shot learning", "zero-shot learning", "fine-tuning",
            "supervised learning", "unsupervised learning", "semi-supervised learning",
            "convolutional neural network", "recurrent neural network", "long short-term memory",
            "graph neural network", "variational autoencoder", "diffusion model",
            "prompt engineering", "in-context learning", "retrieval augmented generation"
        ]
        
        embeddings = self.embedding_model.encode(concepts)
        return {concept: emb for concept, emb in zip(concepts, embeddings)}
    
    def extract_entities(self, paper: Dict) -> Dict[str, List[Tuple[str, float]]]:
        """
        Extract entities with confidence scores
        
        Args:
            paper: Paper dictionary with title, summary, etc.
            
        Returns:
            Dictionary mapping entity types to lists of (entity, confidence) tuples
        """
        text = f"{paper.get('title', '')} {paper.get('summary', '')}"
        
        entities = {
            "authors": self._extract_authors(paper),
            "categories": self._extract_categories(paper),
            "concepts": self._extract_concepts_nlp(text),
            "keywords": self._extract_keywords_nlp(text),
            "methods": self._extract_methods(text),
            "datasets": self._extract_datasets(text)
        }
        
        return entities
    
    def _extract_authors(self, paper: Dict) -> List[Tuple[str, float]]:
        """Extract authors with confidence (always 1.0 for explicit authors)"""
        authors = paper.get("authors", [])
        return [(str(author), 1.0) for author in authors]
    
    def _extract_categories(self, paper: Dict) -> List[Tuple[str, float]]:
        """Extract categories with confidence"""
        categories = paper.get("categories", [])
        return [(cat, 1.0) for cat in categories]
    
    def _extract_concepts_nlp(self, text: str) -> List[Tuple[str, float]]:
        """
        Extract AI/ML concepts using semantic similarity
        
        Strategy:
        1. Split text into sentences
        2. Compute embeddings for sentences
        3. Match against known concept embeddings
        4. Return concepts above threshold with confidence scores
        """
        if not text:
            return []
        
        # Split into sentences (simple approach, can use spaCy if available)
        sentences = re.split(r'[.!?]+', text)
        sentences = [s.strip() for s in sentences if len(s.strip()) > 10]
        
        if not sentences:
            return []
        
        # Embed sentences
        sentence_embeddings = self.embedding_model.encode(sentences)
        
        # Find matching concepts
        matched_concepts = {}
        for concept, concept_emb in self.concept_embeddings.items():
            # Compute max similarity across sentences
            similarities = np.dot(sentence_embeddings, concept_emb)
            max_sim = float(np.max(similarities))
            
            if max_sim >= self.concept_threshold:
                # Use max similarity as confidence
                if concept not in matched_concepts or max_sim > matched_concepts[concept]:
                    matched_concepts[concept] = max_sim
        
        # Sort by confidence and return
        sorted_concepts = sorted(
            matched_concepts.items(),
            key=lambda x: x[1],
            reverse=True
        )
        
        return sorted_concepts[:15]  # Top 15 concepts
    
    def _extract_keywords_nlp(self, text: str) -> List[Tuple[str, float]]:
        """
        Extract keywords using TF-IDF-like approach with NLP
        
        Strategy:
        1. Use spaCy for POS tagging if available
        2. Extract noun phrases and important terms
        3. Score by frequency and importance
        4. Return top keywords with confidence
        """
        if not text:
            return []
        
        if self.nlp:
            # Use spaCy for better extraction
            doc = self.nlp(text)
            
            # Extract noun phrases and important nouns
            keywords = []
            for chunk in doc.noun_chunks:
                text_lower = chunk.text.lower().strip()
                if len(text_lower) > 3 and len(text_lower.split()) <= 3:
                    keywords.append(text_lower)
            
            # Also extract important nouns/adjectives
            for token in doc:
                if token.pos_ in ["NOUN", "PROPN"] and not token.is_stop:
                    if len(token.text) > 3:
                        keywords.append(token.text.lower())
        else:
            # Fallback: simple extraction
            words = re.findall(r'\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\b', text)
            keywords = [w.lower() for w in words if len(w) > 3]
        
        # Score by frequency
        keyword_counts = Counter(keywords)
        total = sum(keyword_counts.values())
        
        # Compute confidence as normalized frequency
        keyword_scores = [
            (kw, count / total)
            for kw, count in keyword_counts.most_common(20)
            if count >= 2  # Minimum frequency threshold
        ]
        
        return keyword_scores
    
    def _extract_methods(self, text: str) -> List[Tuple[str, float]]:
        """
        Extract mentioned methods/techniques
        
        Strategy: Look for method-like patterns
        """
        methods = []
        
        # Common method patterns
        method_patterns = [
            r'([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\s+(?:method|approach|algorithm|technique|model)',
            r'(?:propose|introduce|present|develop)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)',
        ]
        
        for pattern in method_patterns:
            matches = re.findall(pattern, text, re.IGNORECASE)
            for match in matches:
                if len(match.split()) <= 4:  # Reasonable length
                    methods.append((match, 0.7))  # Medium confidence
        
        return list(set(methods))[:10]
    
    def _extract_datasets(self, text: str) -> List[Tuple[str, float]]:
        """
        Extract mentioned datasets
        
        Strategy: Look for dataset-like patterns
        """
        datasets = []
        
        # Common dataset patterns
        dataset_patterns = [
            r'([A-Z][A-Za-z0-9]+(?:\-[A-Z][A-Za-z0-9]+)*)\s+dataset',
            r'dataset\s+([A-Z][A-Za-z0-9]+(?:\-[A-Z][A-Za-z0-9]+)*)',
            r'([A-Z][A-Za-z]+)\s+benchmark',
        ]
        
        for pattern in dataset_patterns:
            matches = re.findall(pattern, text, re.IGNORECASE)
            for match in matches:
                if len(match) > 2:
                    datasets.append((match, 0.6))  # Lower confidence
        
        return list(set(datasets))[:10]
    
    def filter_by_confidence(
        self,
        entities: Dict[str, List[Tuple[str, float]]],
        min_confidence: float = 0.5
    ) -> Dict[str, List[Tuple[str, float]]]:
        """
        Filter entities by confidence threshold
        
        Args:
            entities: Entity dictionary
            min_confidence: Minimum confidence score
            
        Returns:
            Filtered entities
        """
        filtered = {}
        for entity_type, entity_list in entities.items():
            filtered[entity_type] = [
                (entity, conf) for entity, conf in entity_list
                if conf >= min_confidence
            ]
        return filtered

