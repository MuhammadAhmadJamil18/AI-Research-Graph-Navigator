"""
Model Training Module - Fine-tuning for research domain
"""
import os
import json
from typing import List, Dict
from transformers import (
    AutoTokenizer, 
    AutoModelForCausalLM,
    TrainingArguments,
    Trainer,
    DataCollatorForLanguageModeling
)
from peft import LoraConfig, get_peft_model, TaskType
from datasets import Dataset
import torch


class ModelTrainer:
    """
    Fine-tune language model on research papers
    
    Default model: microsoft/Phi-2 (modern, industry-standard, 2023)
    Supports: Phi-2, Mistral, Llama-2, Qwen, GPT-2, DialoGPT
    """
    
    def __init__(
        self,
        base_model: str = "microsoft/Phi-2",  # Modern, industry-standard model (2023)
        output_dir: str = "models/fine-tuned"
    ):
        """
        Initialize model trainer
        
        Args:
            base_model: Hugging Face model name
            output_dir: Directory to save fine-tuned model
        """
        self.base_model = base_model
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
        
        # Initialize tokenizer and model
        print(f"Loading model: {base_model}")
        print("Note: This may take a few minutes for first-time download...")
        
        # Load tokenizer
        self.tokenizer = AutoTokenizer.from_pretrained(
            base_model,
            trust_remote_code=True  # Required for some modern models
        )
        
        # Set pad token if not present
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
            self.tokenizer.pad_token_id = self.tokenizer.eos_token_id
        
        # Determine optimal dtype and device
        if torch.cuda.is_available():
            torch_dtype = torch.float16
            device_map = "auto"
            print("Using GPU with float16 precision")
        else:
            torch_dtype = torch.float32
            device_map = None
            print("Using CPU with float32 precision")
        
        # Load model with appropriate settings
        self.model = AutoModelForCausalLM.from_pretrained(
            base_model,
            torch_dtype=torch_dtype,
            device_map=device_map,
            trust_remote_code=True,  # Required for Phi, Qwen, etc.
            low_cpu_mem_usage=True
        )
        
        # Setup LoRA for efficient fine-tuning
        self.setup_lora()
        
    def setup_lora(self):
        """Setup LoRA (Low-Rank Adaptation) for efficient fine-tuning"""
        # Auto-detect target modules based on model architecture
        target_modules = self._get_target_modules()
        
        lora_config = LoraConfig(
            task_type=TaskType.CAUSAL_LM,
            r=16,  # Higher rank for better quality (modern models can handle it)
            lora_alpha=32,  # Alpha = 2 * r
            lora_dropout=0.1,
            target_modules=target_modules,
            bias="none"
        )
        
        self.model = get_peft_model(self.model, lora_config)
        self.model.print_trainable_parameters()
    
    def _get_target_modules(self):
        """Auto-detect target modules based on model architecture"""
        model_name_lower = self.base_model.lower()
        
        # Modern models (Phi, Mistral, Llama, Qwen)
        if any(x in model_name_lower for x in ["phi", "mistral", "llama", "qwen", "gemma"]):
            return ["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"]
        
        # GPT-2 style models
        elif "gpt2" in model_name_lower or "dialo" in model_name_lower:
            return ["c_attn", "c_proj"]
        
        # Default: try common patterns
        else:
            # Try to auto-detect from model structure
            try:
                if hasattr(self.model, 'model'):
                    if hasattr(self.model.model, 'layers'):
                        first_layer = self.model.model.layers[0]
                        if hasattr(first_layer, 'self_attn'):
                            return ["q_proj", "k_proj", "v_proj", "o_proj"]
            except:
                pass
            
            # Fallback to GPT-2 style
            return ["c_attn", "c_proj"]
    
    def prepare_training_data(self, papers: List[Dict]) -> Dataset:
        """
        Prepare training data from papers
        
        Args:
            papers: List of paper dictionaries
            
        Returns:
            Hugging Face Dataset
        """
        # Create training examples
        training_texts = []
        
        for paper in papers:
            # Format as question-answer pairs or text completion
            title = paper.get('title', '')
            summary = paper.get('summary', '')
            
            # Create training examples
            # Example 1: Title -> Summary
            text = f"Title: {title}\nSummary: {summary}\n"
            training_texts.append(text)
            
            # Example 2: Research paper format
            text = f"Research Paper:\nTitle: {title}\nAbstract: {summary}\n"
            training_texts.append(text)
        
        # Tokenize
        def tokenize_function(examples):
            return self.tokenizer(
                examples["text"],
                truncation=True,
                max_length=512,
                padding="max_length"
            )
        
        dataset = Dataset.from_dict({"text": training_texts})
        tokenized_dataset = dataset.map(
            tokenize_function,
            batched=True,
            remove_columns=["text"]
        )
        
        return tokenized_dataset
    
    def train(
        self,
        train_dataset: Dataset,
        num_epochs: int = 3,
        batch_size: int = 4,
        learning_rate: float = 5e-5
    ):
        """
        Train the model
        
        Args:
            train_dataset: Training dataset
            num_epochs: Number of training epochs
            batch_size: Batch size
            learning_rate: Learning rate
        """
        # Split dataset
        split_dataset = train_dataset.train_test_split(test_size=0.1)
        train_data = split_dataset["train"]
        eval_data = split_dataset["test"]
        
        # Training arguments
        training_args = TrainingArguments(
            output_dir=self.output_dir,
            num_train_epochs=num_epochs,
            per_device_train_batch_size=batch_size,
            per_device_eval_batch_size=batch_size,
            learning_rate=learning_rate,
            warmup_steps=100,
            logging_steps=10,
            eval_strategy="epoch",
            save_strategy="epoch",
            load_best_model_at_end=True,
            push_to_hub=False
        )
        
        # Data collator
        data_collator = DataCollatorForLanguageModeling(
            tokenizer=self.tokenizer,
            mlm=False  # Causal LM, not masked LM
        )
        
        # Trainer
        trainer = Trainer(
            model=self.model,
            args=training_args,
            train_dataset=train_data,
            eval_dataset=eval_data,
            data_collator=data_collator
        )
        
        # Train
        print("Starting training...")
        trainer.train()
        
        # Save model
        trainer.save_model()
        self.tokenizer.save_pretrained(self.output_dir)
        
        print(f"Model saved to {self.output_dir}")
    
    def generate(self, prompt: str, max_length: int = 200, temperature: float = 0.7, top_p: float = 0.9) -> str:
        """
        Generate text using fine-tuned model
        
        Args:
            prompt: Input prompt
            max_length: Maximum generation length
            temperature: Sampling temperature (controls randomness)
            top_p: Nucleus sampling parameter (controls diversity)
            
        Returns:
            Generated text
        """
        # Tokenize and move to same device as model
        inputs = self.tokenizer(prompt, return_tensors="pt")
        
        # Move inputs to model device
        if hasattr(self.model, 'device'):
            inputs = {k: v.to(self.model.device) for k, v in inputs.items()}
        elif torch.cuda.is_available() and next(self.model.parameters()).is_cuda:
            inputs = {k: v.cuda() for k, v in inputs.items()}
        
        with torch.no_grad():
            outputs = self.model.generate(
                **inputs,
                max_length=max_length,
                temperature=temperature,
                top_p=top_p,
                do_sample=True,
                pad_token_id=self.tokenizer.eos_token_id
            )
        
        generated_text = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
        return generated_text
    
    def load_model(self, model_path: str = None):
        """Load fine-tuned model"""
        if model_path is None:
            model_path = self.output_dir
        
        if os.path.exists(model_path):
            self.tokenizer = AutoTokenizer.from_pretrained(model_path)
            self.model = AutoModelForCausalLM.from_pretrained(model_path)
            print(f"Model loaded from {model_path}")
            return True
        return False

