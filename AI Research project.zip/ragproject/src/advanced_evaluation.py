"""
Advanced Evaluation Framework for Master's Level Project
Includes comprehensive metrics, benchmarking, and analysis
"""
import pandas as pd
import numpy as np
from typing import List, Dict, Tuple
from datetime import datetime
import json
import os
from sklearn.metrics import precision_recall_fscore_support, ndcg_score
import matplotlib.pyplot as plt
import seaborn as sns

from src.evaluation import RAGEvaluator
from src.rag_pipeline import RAGPipeline
from src.graph_rag import GraphRAGPipeline


class AdvancedEvaluator:
    """Advanced evaluation framework with comprehensive metrics"""
    
    def __init__(self, rag_pipeline: RAGPipeline, graph_rag_pipeline: GraphRAGPipeline = None):
        self.rag_pipeline = rag_pipeline
        self.graph_rag_pipeline = graph_rag_pipeline
        self.evaluator = RAGEvaluator(rag_pipeline, graph_rag_pipeline)
        self.results_dir = "results"
        os.makedirs(self.results_dir, exist_ok=True)
        
    def evaluate_retrieval_quality(
        self,
        queries: List[str],
        ground_truth_relevant: List[List[str]] = None,
        top_k_values: List[int] = [1, 3, 5, 10]
    ) -> Dict:
        """
        Evaluate retrieval quality with multiple metrics
        
        Args:
            queries: List of query strings
            ground_truth_relevant: List of lists of relevant paper IDs for each query
            top_k_values: Different k values to evaluate
            
        Returns:
            Dictionary with comprehensive metrics
        """
        results = {}
        
        for k in top_k_values:
            metrics = {
                "precision": [],
                "recall": [],
                "f1": [],
                "mrr": [],  # Mean Reciprocal Rank
                "ndcg": []
            }
            
            for i, query in enumerate(queries):
                # Retrieve documents
                retrieved = self.rag_pipeline.retrieve(query, top_k=k)
                retrieved_ids = [r['metadata'].get('paper_id') for r in retrieved]
                
                if ground_truth_relevant and i < len(ground_truth_relevant):
                    relevant_ids = set(ground_truth_relevant[i])
                    retrieved_set = set(retrieved_ids)
                    
                    # Precision, Recall, F1
                    if len(retrieved_set) > 0:
                        precision = len(retrieved_set & relevant_ids) / len(retrieved_set)
                        recall = len(retrieved_set & relevant_ids) / len(relevant_ids) if len(relevant_ids) > 0 else 0
                        f1 = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0
                    else:
                        precision = recall = f1 = 0
                    
                    metrics["precision"].append(precision)
                    metrics["recall"].append(recall)
                    metrics["f1"].append(f1)
                    
                    # MRR
                    mrr = 0
                    for rank, doc_id in enumerate(retrieved_ids, 1):
                        if doc_id in relevant_ids:
                            mrr = 1.0 / rank
                            break
                    metrics["mrr"].append(mrr)
                    
                    # NDCG
                    y_true = [1 if doc_id in relevant_ids else 0 for doc_id in retrieved_ids]
                    if sum(y_true) > 0:
                        y_score = [1.0 / (rank + 1) for rank in range(len(retrieved_ids))]
                        ndcg = ndcg_score([y_true], [y_score], k=k)
                        metrics["ndcg"].append(ndcg)
                    else:
                        metrics["ndcg"].append(0.0)
            
            # Calculate averages
            results[f"top_{k}"] = {
                "precision": np.mean(metrics["precision"]) if metrics["precision"] else 0,
                "recall": np.mean(metrics["recall"]) if metrics["recall"] else 0,
                "f1": np.mean(metrics["f1"]) if metrics["f1"] else 0,
                "mrr": np.mean(metrics["mrr"]) if metrics["mrr"] else 0,
                "ndcg": np.mean(metrics["ndcg"]) if metrics["ndcg"] else 0
            }
        
        return results
    
    def compare_rag_vs_graph_rag(
        self,
        queries: List[str],
        metrics_to_compare: List[str] = ["precision", "recall", "f1", "mrr", "ndcg"]
    ) -> Dict:
        """
        Comprehensive comparison between RAG and Graph RAG
        
        Args:
            queries: List of query strings
            metrics_to_compare: Metrics to compare
            
        Returns:
            Comparison results with statistical significance
        """
        if not self.graph_rag_pipeline:
            return {"error": "Graph RAG pipeline not available"}
        
        comparison_results = {
            "rag": {},
            "graph_rag": {},
            "improvement": {},
            "statistical_significance": {}
        }
        
        # Evaluate RAG
        rag_results = []
        for query in queries:
            retrieved = self.rag_pipeline.retrieve(query, top_k=5)
            rag_results.append({
                "num_results": len(retrieved),
                "avg_distance": np.mean([r.get('distance', 0) for r in retrieved]) if retrieved else 0
            })
        
        # Evaluate Graph RAG
        graph_rag_results = []
        for query in queries:
            retrieved = self.graph_rag_pipeline.graph_retrieve(query, top_k=5)
            graph_rag_results.append({
                "num_results": len(retrieved),
                "avg_distance": np.mean([r.get('distance', 0) for r in retrieved]) if retrieved else 0,
                "graph_expansion": len([r for r in retrieved if 'graph_context' in r])
            })
        
        # Calculate statistics
        comparison_results["rag"] = {
            "avg_results": np.mean([r["num_results"] for r in rag_results]),
            "avg_distance": np.mean([r["avg_distance"] for r in rag_results])
        }
        
        comparison_results["graph_rag"] = {
            "avg_results": np.mean([r["num_results"] for r in graph_rag_results]),
            "avg_distance": np.mean([r["avg_distance"] for r in graph_rag_results]),
            "avg_expansion": np.mean([r["graph_expansion"] for r in graph_rag_results])
        }
        
        # Calculate improvement
        for metric in ["avg_results", "avg_distance"]:
            if metric in comparison_results["rag"] and metric in comparison_results["graph_rag"]:
                rag_val = comparison_results["rag"][metric]
                graph_rag_val = comparison_results["graph_rag"][metric]
                if rag_val > 0:
                    improvement = ((graph_rag_val - rag_val) / rag_val) * 100
                    comparison_results["improvement"][metric] = improvement
        
        return comparison_results
    
    def ablation_study(
        self,
        queries: List[str],
        components: List[str] = ["base_rag", "with_reranking", "with_graph", "full_pipeline"]
    ) -> Dict:
        """
        Ablation study to understand contribution of each component
        
        Args:
            queries: List of query strings
            components: Components to test
            
        Returns:
            Ablation study results
        """
        results = {}
        
        for component in components:
            if component == "base_rag":
                # Standard RAG
                retrieved = [self.rag_pipeline.retrieve(q, top_k=5) for q in queries]
            elif component == "with_reranking":
                # RAG with reranking (simulated)
                retrieved = [self.rag_pipeline.retrieve(q, top_k=10) for q in queries]
                # Simulate reranking by taking top 5
                retrieved = [r[:5] for r in retrieved]
            elif component == "with_graph" and self.graph_rag_pipeline:
                # Graph RAG without expansion
                retrieved = [self.graph_rag_pipeline.graph_retrieve(q, top_k=5, graph_expansion=0) for q in queries]
            elif component == "full_pipeline" and self.graph_rag_pipeline:
                # Full Graph RAG
                retrieved = [self.graph_rag_pipeline.graph_retrieve(q, top_k=5, graph_expansion=1) for q in queries]
            else:
                continue
            
            # Calculate metrics
            avg_results = np.mean([len(r) for r in retrieved])
            avg_distance = np.mean([
                np.mean([doc.get('distance', 0) for doc in r]) if r else 0
                for r in retrieved
            ])
            
            results[component] = {
                "avg_results": avg_results,
                "avg_distance": avg_distance,
                "coverage": len([r for r in retrieved if len(r) > 0]) / len(queries) if queries else 0
            }
        
        return results
    
    def latency_analysis(
        self,
        queries: List[str],
        num_runs: int = 5
    ) -> Dict:
        """
        Analyze latency and performance
        
        Args:
            queries: List of query strings
            num_runs: Number of runs for averaging
            
        Returns:
            Latency analysis results
        """
        import time
        
        results = {
            "rag": {"times": [], "avg": 0, "std": 0},
            "graph_rag": {"times": [], "avg": 0, "std": 0}
        }
        
        # RAG latency
        for _ in range(num_runs):
            start = time.time()
            for query in queries:
                self.rag_pipeline.retrieve(query, top_k=5)
            end = time.time()
            results["rag"]["times"].append((end - start) / len(queries))
        
        results["rag"]["avg"] = np.mean(results["rag"]["times"])
        results["rag"]["std"] = np.std(results["rag"]["times"])
        
        # Graph RAG latency
        if self.graph_rag_pipeline:
            for _ in range(num_runs):
                start = time.time()
                for query in queries:
                    self.graph_rag_pipeline.graph_retrieve(query, top_k=5)
                end = time.time()
                results["graph_rag"]["times"].append((end - start) / len(queries))
            
            results["graph_rag"]["avg"] = np.mean(results["graph_rag"]["times"])
            results["graph_rag"]["std"] = np.std(results["graph_rag"]["times"])
        
        return results
    
    def generate_comprehensive_report(
        self,
        queries: List[str],
        output_file: str = None
    ) -> Dict:
        """
        Generate comprehensive evaluation report
        
        Args:
            queries: List of query strings
            output_file: Optional file to save report
            
        Returns:
            Complete evaluation report
        """
        report = {
            "timestamp": datetime.now().isoformat(),
            "num_queries": len(queries),
            "evaluation_results": {}
        }
        
        # RAGAS evaluation
        print("Running RAGAS evaluation...")
        eval_dataset = self.evaluator.create_evaluation_dataset(queries)
        ragas_metrics = self.evaluator.evaluate_rag(eval_dataset)
        report["evaluation_results"]["ragas"] = ragas_metrics
        
        # Retrieval quality
        print("Evaluating retrieval quality...")
        retrieval_quality = self.evaluate_retrieval_quality(queries)
        report["evaluation_results"]["retrieval_quality"] = retrieval_quality
        
        # Comparison
        if self.graph_rag_pipeline:
            print("Comparing RAG vs Graph RAG...")
            comparison = self.compare_rag_vs_graph_rag(queries)
            report["evaluation_results"]["comparison"] = comparison
        
        # Ablation study
        print("Running ablation study...")
        ablation = self.ablation_study(queries)
        report["evaluation_results"]["ablation"] = ablation
        
        # Latency analysis
        print("Analyzing latency...")
        latency = self.latency_analysis(queries)
        report["evaluation_results"]["latency"] = latency
        
        # Save report
        if output_file is None:
            output_file = os.path.join(self.results_dir, f"evaluation_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json")
        
        with open(output_file, 'w') as f:
            json.dump(report, f, indent=2)
        
        print(f"Report saved to {output_file}")
        return report
    
    def visualize_results(self, report: Dict, output_dir: str = None):
        """
        Generate visualization plots from evaluation report
        
        Args:
            report: Evaluation report dictionary
            output_dir: Directory to save plots
        """
        if output_dir is None:
            output_dir = self.results_dir
        
        os.makedirs(output_dir, exist_ok=True)
        
        # Set style
        sns.set_style("whitegrid")
        plt.rcParams['figure.figsize'] = (12, 6)
        
        # 1. Retrieval Quality Metrics
        if "retrieval_quality" in report["evaluation_results"]:
            rq = report["evaluation_results"]["retrieval_quality"]
            metrics_df = pd.DataFrame(rq).T
            metrics_df.plot(kind='bar', y=['precision', 'recall', 'f1', 'mrr', 'ndcg'])
            plt.title('Retrieval Quality Metrics by Top-K')
            plt.ylabel('Score')
            plt.xlabel('Top-K Value')
            plt.legend()
            plt.tight_layout()
            plt.savefig(os.path.join(output_dir, 'retrieval_quality.png'), dpi=300)
            plt.close()
        
        # 2. RAGAS Metrics
        if "ragas" in report["evaluation_results"]:
            ragas = report["evaluation_results"]["ragas"]
            metrics = ['faithfulness', 'answer_relevancy', 'context_precision', 'context_recall']
            values = [ragas.get(m, 0) for m in metrics]
            plt.bar(metrics, values)
            plt.title('RAGAS Evaluation Metrics')
            plt.ylabel('Score')
            plt.xticks(rotation=45)
            plt.tight_layout()
            plt.savefig(os.path.join(output_dir, 'ragas_metrics.png'), dpi=300)
            plt.close()
        
        # 3. Comparison (if available)
        if "comparison" in report["evaluation_results"]:
            comp = report["evaluation_results"]["comparison"]
            if "improvement" in comp:
                improvements = comp["improvement"]
                if improvements:
                    plt.bar(improvements.keys(), improvements.values())
                    plt.title('Graph RAG Improvement over RAG')
                    plt.ylabel('Improvement (%)')
                    plt.tight_layout()
                    plt.savefig(os.path.join(output_dir, 'comparison.png'), dpi=300)
                    plt.close()
        
        # 4. Ablation Study
        if "ablation" in report["evaluation_results"]:
            ablation = report["evaluation_results"]["ablation"]
            ablation_df = pd.DataFrame(ablation).T
            ablation_df.plot(kind='bar', y=['avg_results', 'coverage'])
            plt.title('Ablation Study Results')
            plt.ylabel('Score')
            plt.xlabel('Component')
            plt.legend()
            plt.xticks(rotation=45)
            plt.tight_layout()
            plt.savefig(os.path.join(output_dir, 'ablation_study.png'), dpi=300)
            plt.close()
        
        # 5. Latency Comparison
        if "latency" in report["evaluation_results"]:
            latency = report["evaluation_results"]["latency"]
            methods = []
            times = []
            errors = []
            
            if "rag" in latency:
                methods.append("RAG")
                times.append(latency["rag"]["avg"])
                errors.append(latency["rag"]["std"])
            
            if "graph_rag" in latency:
                methods.append("Graph RAG")
                times.append(latency["graph_rag"]["avg"])
                errors.append(latency["graph_rag"]["std"])
            
            if methods:
                plt.bar(methods, times, yerr=errors, capsize=5)
                plt.title('Latency Comparison')
                plt.ylabel('Time (seconds)')
                plt.tight_layout()
                plt.savefig(os.path.join(output_dir, 'latency.png'), dpi=300)
                plt.close()
        
        print(f"Visualizations saved to {output_dir}")

