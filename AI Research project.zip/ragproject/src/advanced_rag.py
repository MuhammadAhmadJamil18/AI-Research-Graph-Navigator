"""
Advanced RAG Pipeline with Hybrid Search and Reranking
"""
import os
from typing import List, Dict, Optional
from sentence_transformers import SentenceTransformer, CrossEncoder
import numpy as np
from src.rag_pipeline import RAGPipeline


class AdvancedRAGPipeline(RAGPipeline):
    """
    Advanced RAG pipeline with hybrid search (semantic + keyword) and reranking
    """
    
    def __init__(
        self,
        embedding_model: str = "all-MiniLM-L6-v2",
        reranker_model: str = "cross-encoder/ms-marco-MiniLM-L-6-v2",
        chroma_dir: str = "chroma_db",
        collection_name: str = "research_papers",
        hybrid_alpha: float = 0.7
    ):
        """
        Initialize Advanced RAG pipeline
        
        Args:
            embedding_model: Sentence transformer model for embeddings
            reranker_model: Cross-encoder model for reranking
            chroma_dir: Directory for ChromaDB
            collection_name: Collection name
            hybrid_alpha: Weight for semantic search (1-alpha for keyword search)
        """
        super().__init__(embedding_model, chroma_dir, collection_name)
        
        # Initialize reranker
        self.reranker = CrossEncoder(reranker_model)
        self.hybrid_alpha = hybrid_alpha
        
    def keyword_search(self, query: str, top_k: int = 10) -> List[Dict]:
        """
        Keyword-based search using BM25-like approach
        
        Args:
            query: Search query
            top_k: Number of results
            
        Returns:
            List of relevant chunks
        """
        query_terms = set(query.lower().split())
        
        # Get all documents
        all_docs = self.collection.get()
        
        if not all_docs['documents']:
            return []
        
        # Score documents based on term frequency
        scores = []
        for i, doc in enumerate(all_docs['documents']):
            doc_terms = set(doc.lower().split())
            # Simple term overlap score
            overlap = len(query_terms & doc_terms)
            scores.append((i, overlap))
        
        # Sort by score
        scores.sort(key=lambda x: x[1], reverse=True)
        
        # Get top_k results
        results = []
        for idx, score in scores[:top_k]:
            if score > 0:
                chunk = {
                    "text": all_docs['documents'][idx],
                    "metadata": all_docs['metadatas'][idx] if all_docs['metadatas'] else {},
                    "keyword_score": score
                }
                results.append(chunk)
        
        return results
    
    def hybrid_retrieve(self, query: str, top_k: int = 5) -> List[Dict]:
        """
        Hybrid retrieval combining semantic and keyword search
        
        Args:
            query: Search query
            top_k: Number of results
            
        Returns:
            List of relevant chunks with combined scores
        """
        # Semantic search
        semantic_results = self.retrieve(query, top_k=top_k * 2)
        
        # Keyword search
        keyword_results = self.keyword_search(query, top_k=top_k * 2)
        
        # Normalize scores
        semantic_scores = {}
        for result in semantic_results:
            chunk_id = f"{result['metadata'].get('paper_id', '')}_{result['metadata'].get('chunk_index', '')}"
            # Convert distance to similarity (1 - distance for cosine)
            similarity = 1 - result.get('distance', 1.0)
            semantic_scores[chunk_id] = similarity
        
        keyword_scores = {}
        max_keyword_score = max([r.get('keyword_score', 0) for r in keyword_results]) if keyword_results else 1
        for result in keyword_results:
            chunk_id = f"{result['metadata'].get('paper_id', '')}_{result['metadata'].get('chunk_index', '')}"
            normalized_score = result.get('keyword_score', 0) / max_keyword_score if max_keyword_score > 0 else 0
            keyword_scores[chunk_id] = normalized_score
        
        # Combine results
        all_chunks = {}
        for result in semantic_results:
            chunk_id = f"{result['metadata'].get('paper_id', '')}_{result['metadata'].get('chunk_index', '')}"
            all_chunks[chunk_id] = result
        
        for result in keyword_results:
            chunk_id = f"{result['metadata'].get('paper_id', '')}_{result['metadata'].get('chunk_index', '')}"
            if chunk_id not in all_chunks:
                all_chunks[chunk_id] = result
        
        # Calculate hybrid scores
        hybrid_results = []
        for chunk_id, chunk in all_chunks.items():
            semantic_score = semantic_scores.get(chunk_id, 0)
            keyword_score = keyword_scores.get(chunk_id, 0)
            
            hybrid_score = (
                self.hybrid_alpha * semantic_score +
                (1 - self.hybrid_alpha) * keyword_score
            )
            
            chunk['hybrid_score'] = hybrid_score
            chunk['semantic_score'] = semantic_score
            chunk['keyword_score'] = keyword_score
            hybrid_results.append(chunk)
        
        # Sort by hybrid score
        hybrid_results.sort(key=lambda x: x.get('hybrid_score', 0), reverse=True)
        
        return hybrid_results[:top_k]
    
    def rerank(self, query: str, candidates: List[Dict], top_k: int = 5) -> List[Dict]:
        """
        Rerank candidates using cross-encoder
        
        Args:
            query: Search query
            candidates: List of candidate chunks
            top_k: Number of results after reranking
            
        Returns:
            Reranked list of chunks
        """
        if not candidates:
            return []
        
        # Prepare pairs for reranking
        pairs = [[query, chunk['text']] for chunk in candidates]
        
        # Get reranking scores
        rerank_scores = self.reranker.predict(pairs)
        
        # Add scores to candidates
        for i, chunk in enumerate(candidates):
            chunk['rerank_score'] = float(rerank_scores[i])
        
        # Sort by rerank score
        candidates.sort(key=lambda x: x.get('rerank_score', 0), reverse=True)
        
        return candidates[:top_k]
    
    def advanced_retrieve(
        self,
        query: str,
        top_k: int = 5,
        use_hybrid: bool = True,
        use_reranking: bool = True
    ) -> List[Dict]:
        """
        Advanced retrieval with hybrid search and reranking
        
        Args:
            query: Search query
            top_k: Number of results
            use_hybrid: Whether to use hybrid search
            use_reranking: Whether to use reranking
            
        Returns:
            List of relevant chunks
        """
        # Step 1: Initial retrieval
        if use_hybrid:
            candidates = self.hybrid_retrieve(query, top_k=top_k * 2)
        else:
            candidates = self.retrieve(query, top_k=top_k * 2)
        
        # Step 2: Reranking
        if use_reranking and candidates:
            candidates = self.rerank(query, candidates, top_k=top_k)
        else:
            candidates = candidates[:top_k]
        
        return candidates

