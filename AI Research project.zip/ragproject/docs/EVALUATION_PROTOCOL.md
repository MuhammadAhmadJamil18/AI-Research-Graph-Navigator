# Evaluation Protocol

## Overview

This document defines the comprehensive evaluation protocol for comparing RAG, Graph RAG, and Advanced RAG methods.

## Evaluation Metrics

### Primary Metrics (RAGAS)

1. **Faithfulness** (0-1)
   - Measures if answer is grounded in context
   - Higher is better

2. **Answer Relevancy** (0-1)
   - Measures relevance of answer to question
   - Higher is better

3. **Context Precision** (0-1)
   - Precision of retrieved context
   - Higher is better

4. **Context Recall** (0-1)
   - Recall of retrieved context
   - Higher is better

### Secondary Metrics

1. **Retrieval Time** (ms)
   - Average time per query
   - Lower is better

2. **Throughput** (queries/second)
   - Queries processed per second
   - Higher is better

3. **Memory Usage** (MB)
   - Peak memory during retrieval
   - Lower is better

## Baselines

### 1. BM25 Baseline

**Implementation**: Keyword-based retrieval using BM25
**Purpose**: Traditional IR baseline
**Expected Performance**: Good for keyword-heavy queries, poor for semantic queries

### 2. TF-IDF Baseline

**Implementation**: Term frequency-inverse document frequency
**Purpose**: Classic vector space model
**Expected Performance**: Similar to BM25

### 3. Random Retrieval

**Implementation**: Random chunk selection
**Purpose**: Lower bound baseline
**Expected Performance**: Poor across all metrics

## Experimental Setup

### Dataset

- **Source**: ArXiv papers (cs.AI, cs.LG, cs.CL)
- **Size**: 50-100 papers
- **Split**: 80% training/construction, 20% evaluation

### Query Set

**Query Types**:
1. **Factual**: "What is machine learning?"
2. **Comparative**: "Difference between RNN and LSTM?"
3. **How-to**: "How do neural networks learn?"
4. **Application**: "Applications of computer vision?"
5. **Relationship**: "Papers related to transformers?"

**Query Distribution**:
- 20% Factual
- 20% Comparative
- 20% How-to
- 20% Application
- 20% Relationship

**Total Queries**: 50-100 queries

### Ground Truth

- Manual annotation by domain experts
- Multiple annotators for inter-annotator agreement
- Consensus-based ground truth

## Ablation Studies

### Study 1: RAG Components

**Variants**:
1. Standard RAG (baseline)
2. RAG + Reranking
3. RAG + Deduplication
4. RAG + Reranking + Deduplication

**Hypothesis**: Each component improves quality

### Study 2: Graph RAG Impact

**Variants**:
1. Standard RAG
2. Graph RAG (depth=1)
3. Graph RAG (depth=2)
4. Graph RAG (depth=3)

**Hypothesis**: Graph expansion improves recall, but depth has diminishing returns

### Study 3: Chunking Strategies

**Variants**:
1. Fixed chunking (baseline)
2. Semantic chunking
3. Section-aware chunking

**Hypothesis**: Semantic chunking improves precision

### Study 4: Hybrid Search

**Variants**:
1. Semantic only (alpha=1.0)
2. Keyword only (alpha=0.0)
3. Hybrid (alpha=0.5)
4. Hybrid (alpha=0.7)
5. Hybrid (alpha=0.9)

**Hypothesis**: Hybrid search (alpha=0.7) provides best balance

## Statistical Analysis

### Significance Testing

**Method**: Paired t-test
**Null Hypothesis**: No difference between methods
**Alternative Hypothesis**: Method A > Method B
**Significance Level**: α = 0.05

### Effect Size

**Cohen's d**: Measure of practical significance
- Small: d < 0.2
- Medium: 0.2 ≤ d < 0.5
- Large: d ≥ 0.5

### Confidence Intervals

Report 95% confidence intervals for all metrics

## Results Reporting

### Metrics Table Template

| Method | Faithfulness | Answer Relevancy | Context Precision | Context Recall | Avg Retrieval Time (ms) |
|--------|--------------|------------------|-------------------|----------------|-------------------------|
| BM25 Baseline | X.XX ± Y.YY | X.XX ± Y.YY | X.XX ± Y.YY | X.XX ± Y.YY | XXX ± YY |
| Standard RAG | X.XX ± Y.YY | X.XX ± Y.YY | X.XX ± Y.YY | X.XX ± Y.YY | XXX ± YY |
| Graph RAG | X.XX ± Y.YY | X.XX ± Y.YY | X.XX ± Y.YY | X.XX ± Y.YY | XXX ± YY |
| Advanced RAG | X.XX ± Y.YY | X.XX ± Y.YY | X.XX ± Y.YY | X.XX ± Y.YY | XXX ± YY |

### Statistical Significance Table

| Comparison | Metric | p-value | Effect Size (d) | Significant? |
|------------|--------|---------|-----------------|--------------|
| Graph RAG vs RAG | Context Recall | X.XXX | X.XX | Yes/No |
| Advanced vs RAG | Context Precision | X.XXX | X.XX | Yes/No |

## Expected Insights

1. **Graph RAG improves recall**: Graph expansion finds more relevant papers
2. **Reranking improves precision**: Cross-encoder better ranks results
3. **Deduplication reduces redundancy**: Fewer duplicate chunks
4. **Hybrid search balances**: Combines strengths of semantic and keyword
5. **Semantic chunking preserves context**: Better than fixed chunking

## Reproducibility

### Random Seeds

- Set random seeds for all stochastic operations
- Document seed values in results

### Configuration

- All hyperparameters in `config.yaml`
- Version control all configurations

### Data

- Share paper IDs and queries
- Provide data loading scripts

## Implementation

See `src/evaluation.py` and `src/benchmarking.py` for implementation details.

---

This protocol ensures rigorous, reproducible evaluation suitable for publication.

