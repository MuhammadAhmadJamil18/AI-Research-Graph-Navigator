# How It Works: Complete System Explanation

## Overview

This document explains how the AI Research Graph Navigator works from start to finish, what data it needs, and how each component processes that data.

## System Flow: End-to-End

```
1. DATA INGESTION
   ↓
2. KNOWLEDGE GRAPH CONSTRUCTION
   ↓
3. VECTOR DATABASE CREATION
   ↓
4. RETRIEVAL (RAG/Graph RAG)
   ↓
5. GENERATION & EVALUATION
```

Let's break down each step:

---

## Step 1: Data Ingestion

### What Data Do You Need?

**Input**: Research papers from ArXiv

**What the system fetches:**
- Paper title
- Abstract/summary
- Authors (list of names)
- Categories (e.g., "cs.AI", "cs.LG")
- Publication date
- Paper ID
- PDF URL

### How It Works

```python
# 1. You specify what papers to fetch
query = "cat:cs.AI OR cat:cs.LG"  # AI/ML papers
num_papers = 50

# 2. System fetches from ArXiv API
ingester = ArXivIngester()
papers = ingester.fetch_papers(query=query, max_results=num_papers)

# 3. Papers are saved locally
ingester.save_papers(papers)  # Saves to data/papers.json
```

**Example Paper Data:**
```json
{
  "id": "2312.12345",
  "title": "Attention Is All You Need",
  "authors": ["Vaswani, Ashish", "Shazeer, Noam"],
  "summary": "We propose a new simple network architecture...",
  "categories": ["cs.CL", "cs.LG"],
  "published": "2023-12-01T00:00:00Z"
}
```

**Output**: List of paper dictionaries saved to `data/papers.json`

---

## Step 2: Knowledge Graph Construction

### What Data Does It Use?

**Input**: The papers from Step 1

### How It Works

#### 2.1 Entity Extraction

For each paper, the system extracts:

1. **Authors** (from paper metadata)
   - Example: ["Vaswani, Ashish", "Shazeer, Noam"]
   - Confidence: 1.0 (always accurate)

2. **Categories** (from paper metadata)
   - Example: ["cs.CL", "cs.LG"]
   - Confidence: 1.0

3. **Concepts** (using NLP/semantic matching)
   - How: Compares paper text to known AI/ML concepts
   - Example: Finds "transformer", "attention mechanism", "neural network"
   - Confidence: 0.6-0.9 (based on semantic similarity)

4. **Keywords** (using NLP)
   - How: Extracts important terms, noun phrases
   - Example: ["self-attention", "encoder-decoder", "positional encoding"]
   - Confidence: 0.5-0.8 (based on frequency and importance)

5. **Methods** (pattern matching)
   - How: Finds method-like patterns in text
   - Example: "Transformer architecture", "BERT model"
   - Confidence: 0.6-0.7

```python
# Entity extraction process
extractor = EntityExtractor()
for paper in papers:
    entities = extractor.extract_entities(paper)
    # Returns: {
    #   "authors": [("Vaswani, Ashish", 1.0), ...],
    #   "concepts": [("transformer", 0.85), ("attention", 0.78), ...],
    #   "keywords": [("self-attention", 0.65), ...],
    #   ...
    # }
```

#### 2.2 Graph Building

The system creates a graph with:

**Nodes** (entities):
- Paper nodes: One per paper
- Author nodes: One per unique author
- Concept nodes: One per unique concept
- Category nodes: One per category
- Keyword nodes: Top keywords per paper

**Edges** (relationships):
- `paper → author`: "authored_by" (weight = confidence)
- `paper → concept`: "discusses" (weight = confidence)
- `paper → category`: "belongs_to" (weight = 1.0)
- `paper → paper`: "similar_author" or "similar_concept" (weight = similarity score)

```python
# Graph building process
builder = ImprovedKnowledgeGraphBuilder()
builder.build_graph(papers)

# Creates graph like:
# Paper1 --[authored_by]--> Author1
# Paper1 --[discusses]--> Concept1 (confidence: 0.85)
# Paper1 --[similar_concept]--> Paper2 (weight: 0.72)
```

**Output**: Knowledge graph saved to `data/knowledge_graph.json`

**Graph Statistics Example:**
- 50 papers → ~300 nodes, ~500 edges
- Node types: 50 papers, 150 authors, 80 concepts, 20 categories

---

## Step 3: Vector Database Creation

### What Data Does It Use?

**Input**: Papers from Step 1

### How It Works

#### 3.1 Chunking

Each paper is split into smaller chunks:

**Option A: Fixed Chunking** (baseline)
```python
# Simple: Split text into fixed-size pieces
paper_text = "Title: ...\n\nAbstract: ..."
chunks = [
    "Title: ...\n\nAbstract: [first 500 chars]",
    "[next 500 chars with 50 char overlap]",
    ...
]
```

**Option B: Semantic Chunking** (improved)
```python
# Smart: Preserve sections and sentences
chunks = [
    {
        "text": "Title: ...\n\nAbstract: [complete abstract]",
        "section": "Abstract"
    },
    {
        "text": "[Introduction section, sentence-boundary aware]",
        "section": "Introduction"
    },
    ...
]
```

#### 3.2 Embedding Generation

Each chunk is converted to a vector (embedding):

```python
# 1. Load embedding model
embedding_model = SentenceTransformer("all-MiniLM-L-6-v2")

# 2. Generate embeddings for all chunks
chunk_texts = [chunk['chunk_text'] for chunk in chunks]
embeddings = embedding_model.encode(chunk_texts)
# Returns: numpy array of shape (num_chunks, 384)
# Each chunk → 384-dimensional vector
```

**What embeddings capture:**
- Semantic meaning of the text
- Similar chunks have similar vectors
- Enables semantic search

#### 3.3 Vector Storage

Embeddings are stored in ChromaDB:

```python
# Store in vector database
rag = RAGPipeline()
rag.add_documents(chunks)

# Internally:
# - Stores embeddings
# - Stores chunk text
# - Stores metadata (paper_id, title, chunk_index)
# - Creates index for fast search
```

**Output**: Vector database in `chroma_db/` directory

**Example:**
- 50 papers → ~200-300 chunks
- Each chunk: 384-dimensional vector
- Total: ~200-300 vectors ready for search

---

## Step 4: Retrieval (RAG/Graph RAG)

### What Data Does It Use?

**Input**: 
- User query (text question)
- Vector database (from Step 3)
- Knowledge graph (from Step 2, for Graph RAG)

### How It Works

#### 4.1 Standard RAG

```python
# User asks: "What are transformer architectures?"

# Step 1: Convert query to embedding
query_embedding = embedding_model.encode(["What are transformer architectures?"])
# Returns: 384-dimensional vector

# Step 2: Search vector database
results = vector_db.query(
    query_embeddings=[query_embedding],
    n_results=5  # Top 5 chunks
)

# Step 3: Return most similar chunks
# Results ranked by cosine similarity (distance)
```

**What happens:**
1. Query → embedding vector
2. Compare query vector to all chunk vectors
3. Find top 5 most similar chunks
4. Return chunks with metadata

**Output**: Top 5 relevant paper chunks

#### 4.2 Graph RAG (Enhanced)

```python
# User asks: "What are transformer architectures?"

# Step 1: Standard RAG retrieval (as above)
initial_results = rag.retrieve(query, top_k=5)
# Gets: 5 paper chunks

# Step 2: Extract paper IDs from results
paper_ids = [result['metadata']['paper_id'] for result in initial_results]
# Example: ["2312.12345", "2301.67890", ...]

# Step 3: Graph expansion
for paper_id in paper_ids:
    # Find related papers through graph
    neighbors = graph.get_neighbors(paper_id)
    # Gets: Related papers, concepts, authors
    
    # Add related paper chunks to context
    related_chunks = get_chunks_from_papers(neighbors)

# Step 4: Combine initial + expanded results
enhanced_results = initial_results + related_chunks
```

**What Graph RAG adds:**
- Finds papers related through shared authors
- Finds papers discussing similar concepts
- Expands context beyond direct similarity
- Provides richer, more connected information

**Output**: Enhanced results with graph context

#### 4.3 Advanced RAG (Hybrid + Reranking)

```python
# Step 1: Hybrid search
# Combines semantic (70%) + keyword (30%)

semantic_results = vector_search(query)  # Semantic similarity
keyword_results = keyword_search(query)   # Exact keyword matches

# Combine with weighted scores
hybrid_results = combine(semantic_results, keyword_results, alpha=0.7)

# Step 2: Reranking
# Use cross-encoder to re-rank by relevance
reranked = reranker.rerank(query, hybrid_results)
# Cross-encoder considers query + chunk together
# Better than just embedding similarity

# Step 3: Deduplication
# Remove highly similar chunks
final_results = deduplicator.deduplicate(reranked)
```

**What Advanced RAG adds:**
- Hybrid search: Catches both semantic and keyword matches
- Reranking: Better relevance scoring
- Deduplication: Removes redundant chunks

**Output**: Best quality, most relevant chunks

---

## Step 5: Generation & Evaluation

### What Data Does It Use?

**Input**: 
- Retrieved chunks (from Step 4)
- User query
- (Optional) Fine-tuned model

### How It Works

#### 5.1 Context Formatting

```python
# Format retrieved chunks into context
context = format_context(retrieved_chunks)
# Returns:
# """
# [1] Title: Attention Is All You Need
# Transformer architectures use self-attention...
#
# [2] Title: BERT: Pre-training of Deep Bidirectional Transformers
# BERT is based on transformer architecture...
# ...
# """
```

#### 5.2 Prompt Generation

```python
# Create prompt for LLM
prompt = f"""
You are a helpful research assistant. Answer the question based on the following research paper excerpts.

Context from research papers:
{context}

Question: {query}

Answer:
"""
```

#### 5.3 Generation (Optional)

```python
# Option 1: Use fine-tuned model
fine_tuned_model = load_model("models/fine-tuned")
answer = fine_tuned_model.generate(prompt)

# Option 2: Use base LLM (Ollama/HuggingFace)
answer = llm.generate(prompt)

# Option 3: Simplified (for demo)
answer = f"Based on the research papers:\n\n{context[:500]}..."
```

**Output**: Generated answer to user's question

#### 5.4 Evaluation

```python
# Evaluate retrieval quality using RAGAS
evaluator = RAGEvaluator(rag_pipeline)

# Test queries
queries = [
    "What are transformer architectures?",
    "How do neural networks learn?",
    ...
]

# Evaluate
metrics = evaluator.evaluate_rag(queries)

# Returns:
# {
#   "faithfulness": 0.75,      # Answer grounded in context?
#   "answer_relevancy": 0.71,  # Answer relevant to question?
#   "context_precision": 0.69, # Precise context retrieval?
#   "context_recall": 0.67     # Complete context retrieval?
# }
```

---

## Complete Example: End-to-End

### Scenario: User asks "What are transformer architectures?"

#### Step 1: Data Ingestion ✅
- System has 50 papers already fetched
- Papers stored in `data/papers.json`

#### Step 2: Knowledge Graph ✅
- Graph built with 300 nodes, 500 edges
- Includes concepts like "transformer", "attention mechanism"
- Graph stored in `data/knowledge_graph.json`

#### Step 3: Vector Database ✅
- 50 papers → 250 chunks
- All chunks embedded and stored
- Database in `chroma_db/`

#### Step 4: Retrieval
```python
# User query
query = "What are transformer architectures?"

# Standard RAG
results = rag.retrieve(query, top_k=5)
# Returns 5 chunks about transformers

# Graph RAG (enhanced)
graph_results = graph_rag.graph_retrieve(query, top_k=5)
# Returns 5 chunks + related papers through graph

# Advanced RAG (best quality)
advanced_results = advanced_rag.advanced_retrieve(query, top_k=5)
# Returns 5 best chunks after hybrid search + reranking
```

**Retrieved Chunks Example:**
1. "Transformer architectures use self-attention mechanisms..." (from Paper A)
2. "The transformer model was introduced in 'Attention Is All You Need'..." (from Paper B)
3. "BERT and GPT are based on transformer architecture..." (from Paper C)
4. [Related paper through graph] "Vision transformers apply transformers to images..." (from Paper D)
5. [Related paper through graph] "Transformer-based models achieve state-of-the-art..." (from Paper E)

#### Step 5: Generation
```python
# Format context
context = format_context(results)

# Generate answer
answer = generate_answer(query, context)

# Returns:
# "Transformer architectures are neural network architectures 
#  based on self-attention mechanisms. They were introduced in 
#  the paper 'Attention Is All You Need' and have become the 
#  foundation for models like BERT and GPT. Key components 
#  include encoder-decoder structure, multi-head attention, 
#  and positional encoding..."
```

---

## Data Requirements Summary

### Input Data (What You Need)

1. **Research Papers**
   - Source: ArXiv (automatic) or custom dataset
   - Format: JSON with title, summary, authors, categories
   - Quantity: 20-100 papers recommended
   - Quality: Recent, relevant papers work best

2. **Queries** (for evaluation)
   - Format: List of question strings
   - Types: Factual, comparative, how-to, application
   - Quantity: 10-50 queries for evaluation

### Generated Data (What System Creates)

1. **Papers JSON**: `data/papers.json`
   - Raw paper data

2. **Knowledge Graph**: `data/knowledge_graph.json`
   - Nodes: Papers, authors, concepts, categories
   - Edges: Relationships with weights

3. **Vector Database**: `chroma_db/`
   - Embeddings for all chunks
   - Metadata and indices

4. **Fine-tuned Model** (optional): `models/fine-tuned/`
   - Trained model weights

5. **Results**: `results/`
   - Evaluation metrics
   - Benchmark results

---

## How Each Component Processes Data

### Entity Extractor
- **Input**: Paper text (title + summary)
- **Process**: 
  - Semantic similarity matching for concepts
  - NLP extraction for keywords
  - Pattern matching for methods
- **Output**: Entities with confidence scores

### Graph Builder
- **Input**: Papers + extracted entities
- **Process**:
  - Create nodes for each entity
  - Create edges based on relationships
  - Compute similarity weights
  - Prune low-confidence edges
- **Output**: Knowledge graph

### Chunker
- **Input**: Paper text
- **Process**:
  - Split into chunks (fixed or semantic)
  - Preserve context (sections, sentences)
  - Add metadata (section, position)
- **Output**: List of chunks

### RAG Pipeline
- **Input**: Chunks + query
- **Process**:
  - Embed query
  - Search vector database
  - Rank by similarity
  - Return top-k chunks
- **Output**: Relevant chunks

### Graph RAG Pipeline
- **Input**: Chunks + query + knowledge graph
- **Process**:
  - Standard RAG retrieval
  - Graph expansion from retrieved papers
  - Context enhancement
- **Output**: Enhanced chunks with graph context

### Evaluator
- **Input**: Queries + retrieved chunks + (optional) ground truth
- **Process**:
  - Generate answers from context
  - Compute RAGAS metrics
  - Compare methods
- **Output**: Evaluation metrics

---

## Practical Usage

### For Testing
```python
# 1. Fetch papers
papers = fetch_papers(20)

# 2. Build graph
graph = build_graph(papers)

# 3. Create RAG
rag = create_rag(papers)

# 4. Query
results = rag.retrieve("What is machine learning?")

# 5. Evaluate
metrics = evaluate(rag, test_queries)
```

### For Research
```python
# 1. Fetch larger dataset
papers = fetch_papers(100)

# 2. Build improved graph
graph = build_improved_graph(papers)

# 3. Create multiple RAG variants
rag = create_rag(papers)
graph_rag = create_graph_rag(papers, graph)
advanced_rag = create_advanced_rag(papers)

# 4. Run ablation studies
compare_methods([rag, graph_rag, advanced_rag], test_queries)

# 5. Statistical analysis
analyze_results(results)
```

---

## Key Concepts Explained

### Embeddings
- **What**: Numerical representation of text
- **Why**: Enables semantic search (similar meaning = similar numbers)
- **How**: Sentence transformer model converts text → vector

### Knowledge Graph
- **What**: Network of entities and relationships
- **Why**: Captures connections between papers, authors, concepts
- **How**: Extracts entities, creates nodes, connects with edges

### RAG (Retrieval-Augmented Generation)
- **What**: Retrieve relevant context, then generate answer
- **Why**: Better than generation alone (grounded in facts)
- **How**: Vector search → format context → generate

### Graph RAG
- **What**: RAG + graph traversal
- **Why**: Finds related information through graph connections
- **How**: Initial retrieval → graph expansion → enhanced context

---

## Summary

**Data Flow:**
1. Papers (ArXiv) → JSON storage
2. Papers → Entity extraction → Knowledge graph
3. Papers → Chunking → Embedding → Vector database
4. Query → Retrieval → Context → Answer

**Key Data:**
- **Input**: Papers (title, abstract, authors, categories)
- **Generated**: Graph (nodes, edges), Vectors (embeddings), Results (metrics)

**Processing:**
- **Extraction**: NLP-based entity extraction
- **Graph**: Relationship inference and weighting
- **Retrieval**: Semantic search + graph traversal
- **Evaluation**: RAGAS metrics and statistical analysis

Everything is automated once you provide papers and queries!

