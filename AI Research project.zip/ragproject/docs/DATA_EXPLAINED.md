# Data Explained: What Goes In, What Comes Out

## Input Data: What You Need

### 1. Research Papers

**Where to Get:**
- **ArXiv** (automatic): Use built-in fetcher
- **Custom**: Your own JSON files

**What Format:**
```json
{
  "id": "2312.12345",
  "title": "Paper Title",
  "authors": ["Author 1", "Author 2"],
  "summary": "Abstract text here...",
  "categories": ["cs.AI", "cs.LG"],
  "published": "2023-12-01T00:00:00Z",
  "pdf_url": "https://arxiv.org/pdf/2312.12345.pdf"
}
```

**How Much:**
- **Minimum**: 10-20 papers (for testing)
- **Recommended**: 50-100 papers (for research)
- **Optimal**: 100+ papers (for publication)

**What Makes Good Data:**
- ✅ Recent papers (last 2-3 years)
- ✅ Relevant domain (AI/ML for this project)
- ✅ Complete abstracts
- ✅ Multiple authors
- ✅ Clear categories

### 2. Queries (For Evaluation)

**Format:**
```python
queries = [
    "What are transformer architectures?",
    "How do neural networks learn?",
    "What is the difference between RNN and LSTM?",
    "Applications of computer vision?",
    "How does reinforcement learning work?"
]
```

**Types:**
- **Factual**: "What is X?"
- **Comparative**: "Difference between X and Y?"
- **How-to**: "How does X work?"
- **Application**: "Applications of X?"
- **Relationship**: "Papers related to X?"

**How Many:**
- **Testing**: 5-10 queries
- **Evaluation**: 20-50 queries
- **Research**: 50-100 queries

---

## Generated Data: What System Creates

### 1. Papers JSON (`data/papers.json`)

**What It Contains:**
- All fetched papers
- Original metadata
- Timestamp of fetch

**Example:**
```json
[
  {
    "id": "2312.12345",
    "title": "Attention Is All You Need",
    "authors": ["Vaswani, Ashish"],
    "summary": "We propose the Transformer...",
    "categories": ["cs.CL"],
    "published": "2023-12-01T00:00:00Z"
  },
  ...
]
```

**Size:** ~50KB per 10 papers

### 2. Knowledge Graph (`data/knowledge_graph.json`)

**What It Contains:**
- **Nodes**: Papers, authors, concepts, categories, keywords
- **Edges**: Relationships with weights and confidence

**Example:**
```json
{
  "nodes": [
    {
      "id": "2312.12345",
      "node_type": "paper",
      "title": "Attention Is All You Need",
      "confidence": 1.0
    },
    {
      "id": "concept_transformer",
      "node_type": "concept",
      "name": "Transformer",
      "confidence": 0.85
    }
  ],
  "edges": [
    {
      "source": "2312.12345",
      "target": "concept_transformer",
      "relation": "discusses",
      "weight": 0.85,
      "confidence": 0.85
    }
  ]
}
```

**Size:** ~100-200KB for 50 papers

**Statistics Example:**
- 50 papers → ~300 nodes, ~500 edges
- Node breakdown: 50 papers, 150 authors, 80 concepts, 20 categories

### 3. Vector Database (`chroma_db/`)

**What It Contains:**
- Embeddings (384-dimensional vectors)
- Chunk text
- Metadata (paper_id, title, chunk_index)

**Structure:**
```
chroma_db/
├── chroma.sqlite3        # Database file
└── [internal files]     # Indices and metadata
```

**Size:** ~5-10MB for 50 papers (250 chunks)

**What's Inside:**
- Each chunk → 384 numbers (embedding vector)
- Fast search index
- Metadata for each chunk

### 4. Chunks (In Memory)

**What They Look Like:**
```python
{
    "paper_id": "2312.12345",
    "title": "Attention Is All You Need",
    "chunk_text": "We propose the Transformer, a model architecture...",
    "chunk_index": 0,
    "section": "Abstract",  # If semantic chunking
    "start_pos": 0,
    "end_pos": 500
}
```

**How Many:**
- Fixed chunking: ~3-5 chunks per paper
- Semantic chunking: ~4-6 chunks per paper
- 50 papers → ~200-300 total chunks

### 5. Embeddings (In Memory/Vector DB)

**What They Are:**
- Numerical representation of text
- 384 numbers per chunk
- Captures semantic meaning

**Example:**
```python
# Chunk text: "Transformer architectures use self-attention..."
# Embedding: [0.123, -0.456, 0.789, ..., 0.234]  # 384 numbers
```

**Why:**
- Similar text → similar numbers
- Enables semantic search
- Fast comparison

### 6. Evaluation Results (`results/`)

**What It Contains:**
- RAGAS metrics
- Performance metrics
- Comparison tables

**Example:**
```json
{
  "timestamp": "2024-01-15T10:30:00",
  "method": "Standard RAG",
  "metrics": {
    "faithfulness": 0.75,
    "answer_relevancy": 0.71,
    "context_precision": 0.69,
    "context_recall": 0.67
  },
  "performance": {
    "avg_retrieval_time_ms": 45.2,
    "throughput_qps": 22.1
  }
}
```

### 7. Fine-tuned Model (Optional, `models/fine-tuned/`)

**What It Contains:**
- Trained model weights
- Tokenizer
- Configuration

**Size:** ~100-500MB (depending on model)

---

## Data Flow Diagram

```
INPUT
  ↓
[Papers from ArXiv]
  ↓
[Entity Extraction] → [Knowledge Graph]
  ↓                    (nodes, edges)
[Chunking] → [Embedding] → [Vector Database]
  ↓            ↓              (embeddings)
[Chunks]    [Vectors]      [Search Index]
  ↓
[Retrieval] ← [User Query]
  ↓
[Context] → [Generation] → [Answer]
  ↓
[Evaluation] → [Metrics]
```

---

## Data Sizes (Approximate)

| Component | 10 Papers | 50 Papers | 100 Papers |
|-----------|-----------|-----------|------------|
| Papers JSON | ~10 KB | ~50 KB | ~100 KB |
| Knowledge Graph | ~20 KB | ~150 KB | ~300 KB |
| Vector DB | ~1 MB | ~8 MB | ~16 MB |
| Chunks | ~30 | ~250 | ~500 |
| Graph Nodes | ~60 | ~300 | ~600 |
| Graph Edges | ~100 | ~500 | ~1000 |

---

## Data Quality Requirements

### Papers
- ✅ Complete abstracts (at least 200 words)
- ✅ Valid authors (not empty)
- ✅ Relevant categories
- ✅ Recent (for better results)

### Queries
- ✅ Clear questions
- ✅ Relevant to paper domain
- ✅ Diverse types (factual, comparative, etc.)
- ✅ Not too vague or too specific

---

## How to Provide Data

### Option 1: Automatic (ArXiv)
```python
ingester = ArXivIngester()
papers = ingester.fetch_papers(
    query="cat:cs.AI OR cat:cs.LG",
    max_results=50
)
```

### Option 2: Custom JSON
```python
# Create papers.json with your data
papers = [
    {
        "id": "custom_001",
        "title": "Your Paper Title",
        "authors": ["Your Name"],
        "summary": "Your abstract...",
        "categories": ["cs.AI"],
        "published": "2024-01-01T00:00:00Z"
    }
]

ingester = ArXivIngester()
ingester.save_papers(papers)
```

### Option 3: Load Existing
```python
ingester = ArXivIngester()
papers = ingester.load_papers()  # Loads from data/papers.json
```

---

## What Happens to Your Data

### Processing Steps

1. **Papers** → Stored as-is in JSON
2. **Papers** → Entities extracted → Graph nodes/edges
3. **Papers** → Chunked → Embedded → Vector database
4. **Query** → Embedded → Searched → Retrieved chunks
5. **Chunks** → Formatted → Generated answer

### Data Persistence

- **Papers**: Saved to `data/papers.json` (persistent)
- **Graph**: Saved to `data/knowledge_graph.json` (persistent)
- **Vectors**: Saved to `chroma_db/` (persistent)
- **Results**: Saved to `results/` (persistent)

### Data Privacy

- All processing is local
- No data sent to external services (except ArXiv API for fetching)
- You control all data

---

## Summary

**Input:**
- Papers (title, abstract, authors, categories)
- Queries (for evaluation)

**Generated:**
- Knowledge graph (nodes, edges, weights)
- Vector database (embeddings, indices)
- Chunks (processed text segments)
- Results (metrics, evaluations)

**Everything is automated** - just provide papers and queries!

