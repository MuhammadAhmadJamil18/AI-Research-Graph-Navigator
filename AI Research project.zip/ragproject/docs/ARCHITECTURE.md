# System Architecture

## Overview

The AI Research Graph Navigator implements a modular, extensible architecture for research paper exploration using multiple RAG paradigms. This document describes the revised architecture with clear separation of concerns and research-grade design principles.

## Architectural Principles

1. **Separation of Concerns**: Each module has a single, well-defined responsibility
2. **Extensibility**: Easy to add new retrieval methods or evaluation metrics
3. **Reproducibility**: Deterministic, config-driven design
4. **Scalability**: Memory-efficient pipelines for large corpora
5. **Testability**: Modular design enables unit and integration testing

## System Architecture Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                    Data Ingestion Layer                      │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐     │
│  │ ArXiv API    │  │ Preprocessing │  │ Chunking     │     │
│  │ Fetcher      │→ │ & Cleaning    │→ │ Strategies   │     │
│  └──────────────┘  └──────────────┘  └──────────────┘     │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│                  Knowledge Graph Layer                        │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐     │
│  │ Entity       │  │ Relationship │  │ Graph        │     │
│  │ Extraction   │→ │ Construction  │→ │ Storage       │     │
│  │ (NER/NLP)    │  │ & Weighting   │  │ (NetworkX)   │     │
│  └──────────────┘  └──────────────┘  └──────────────┘     │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│                    Retrieval Layer                           │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐     │
│  │ Vector       │  │ Graph        │  │ Hybrid       │     │
│  │ Search       │  │ Traversal    │  │ Retrieval    │     │
│  │ (RAG)        │  │ (Graph RAG)  │  │ (Advanced)   │     │
│  └──────────────┘  └──────────────┘  └──────────────┘     │
│         ↓                ↓                ↓                 │
│  ┌────────────────────────────────────────────────────┐   │
│  │         Reranking & Context Deduplication          │   │
│  └────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│                  Generation & Evaluation Layer                │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐     │
│  │ LLM          │  │ RAGAS        │  │ Benchmarking │     │
│  │ Generation   │  │ Evaluation   │  │ & Analysis   │     │
│  │ (Fine-tuned) │  │ Metrics      │  │ Suite        │     │
│  └──────────────┘  └──────────────┘  └──────────────┘     │
└─────────────────────────────────────────────────────────────┘
```

## Module Responsibilities

### 1. Data Ingestion (`src/data_ingestion.py`)

**Responsibilities:**
- Fetch papers from ArXiv API
- Clean and normalize text
- Implement multiple chunking strategies
- Handle data persistence

**Key Classes:**
- `ArXivIngester`: Main ingestion interface
- `ChunkingStrategy`: Abstract base for chunking methods
- `SemanticChunker`: Section-aware chunking
- `FixedChunker`: Fixed-size chunking (baseline)

**Design Rationale:**
- Separates data fetching from processing
- Enables pluggable chunking strategies
- Supports batch and streaming ingestion

### 2. Knowledge Graph Construction (`src/graph_builder.py`)

**Responsibilities:**
- Extract entities using NLP methods
- Construct relationships with confidence scores
- Apply graph pruning and weighting
- Manage graph storage and retrieval

**Key Classes:**
- `KnowledgeGraphBuilder`: Main graph construction
- `EntityExtractor`: NLP-based entity extraction
- `RelationshipBuilder`: Relationship inference
- `GraphPruner`: Graph optimization

**Design Rationale:**
- Replaces heuristics with learned methods
- Enables confidence-based filtering
- Supports incremental graph updates

### 3. Retrieval Pipelines

#### 3.1 Standard RAG (`src/rag_pipeline.py`)

**Responsibilities:**
- Semantic search using vector embeddings
- Query-aware retrieval
- Context formatting

**Key Classes:**
- `RAGPipeline`: Base RAG implementation
- `EmbeddingModel`: Encapsulates embedding generation
- `VectorStore`: Abstract vector database interface

**Design Rationale:**
- Clean separation of embedding and retrieval
- Enables embedding model swapping
- Supports multiple vector databases

#### 3.2 Graph RAG (`src/graph_rag.py`)

**Responsibilities:**
- Graph-aware retrieval
- Intelligent graph traversal
- Context expansion through relationships

**Key Classes:**
- `GraphRAGPipeline`: Graph-enhanced retrieval
- `GraphTraverser`: Traversal strategies
- `ContextExpander`: Graph-based context enhancement

**Design Rationale:**
- Leverages graph structure for richer context
- Configurable traversal depth and strategies
- Handles disconnected components gracefully

#### 3.3 Advanced RAG (`src/advanced_rag.py`)

**Responsibilities:**
- Hybrid semantic + keyword search
- Cross-encoder reranking
- Context deduplication

**Key Classes:**
- `AdvancedRAGPipeline`: Hybrid retrieval
- `HybridRetriever`: Combines multiple signals
- `Reranker`: Relevance scoring
- `ContextDeduplicator`: Removes redundant context

**Design Rationale:**
- Addresses limitations of pure semantic search
- Improves precision through reranking
- Reduces context redundancy

### 4. Evaluation Framework (`src/evaluation.py`, `src/benchmarking.py`)

**Responsibilities:**
- RAGAS metric computation
- Baseline comparisons
- Ablation study support
- Statistical significance testing

**Key Classes:**
- `RAGEvaluator`: Main evaluation interface
- `BaselineComparator`: Compares against baselines
- `AblationRunner`: Runs ablation studies
- `StatisticalAnalyzer`: Significance testing

**Design Rationale:**
- Comprehensive evaluation beyond RAGAS
- Supports rigorous experimental design
- Enables reproducible comparisons

### 5. Model Training (`src/model_training.py`)

**Responsibilities:**
- Fine-tuning with LoRA
- Instruction formatting
- Training data preparation
- Model evaluation

**Key Classes:**
- `ModelTrainer`: Training orchestration
- `InstructionFormatter`: Formats training data
- `TrainingMonitor`: Tracks training metrics

**Design Rationale:**
- Efficient fine-tuning with PEFT
- Proper instruction formatting for research domain
- Supports multiple base models

## Data Flow

### 1. Ingestion Flow

```
ArXiv API → Raw Papers → Preprocessing → Chunking → Chunked Documents
```

### 2. Graph Construction Flow

```
Papers → Entity Extraction → Relationship Inference → Graph Building → Graph Storage
```

### 3. Retrieval Flow

```
Query → Embedding → Vector Search → (Optional: Graph Expansion) → Reranking → Context Deduplication → Final Results
```

### 4. Evaluation Flow

```
Queries → Retrieval → Generation → RAGAS Metrics → Statistical Analysis → Results
```

## Key Design Decisions

### 1. Modular Architecture

**Decision**: Separate modules for each component
**Rationale**: 
- Enables independent testing
- Facilitates feature addition
- Improves code maintainability

**Alternatives Considered**:
- Monolithic design (rejected: harder to test and extend)
- Microservices (rejected: overkill for research project)

### 2. Strategy Pattern for Chunking

**Decision**: Pluggable chunking strategies
**Rationale**:
- Enables experimentation with different methods
- Easy to add new strategies
- Supports ablation studies

**Implementation**: Abstract base class with concrete implementations

### 3. Graph as Separate Layer

**Decision**: Knowledge graph as independent layer
**Rationale**:
- Graph can be built independently
- Supports graph-only queries
- Enables graph analysis separate from retrieval

**Alternatives Considered**:
- Integrated graph (rejected: less flexible)

### 4. Evaluation as First-Class Component

**Decision**: Comprehensive evaluation framework
**Rationale**:
- Research requires rigorous evaluation
- Enables method comparison
- Supports publication-quality results

## Scalability Considerations

### Memory Efficiency

1. **Lazy Loading**: Load embeddings on-demand
2. **Batch Processing**: Process papers in batches
3. **Streaming**: Support streaming for large datasets
4. **Graph Pruning**: Remove low-confidence edges

### Performance Optimization

1. **Caching**: Cache embeddings and graph structures
2. **Parallel Processing**: Parallelize independent operations
3. **Indexing**: Efficient graph and vector indices
4. **Incremental Updates**: Update graph incrementally

## Extensibility Points

1. **New Chunking Strategies**: Implement `ChunkingStrategy` interface
2. **New Retrieval Methods**: Extend base retrieval classes
3. **New Evaluation Metrics**: Add to evaluation framework
4. **New Entity Types**: Extend entity extractor
5. **New Graph Algorithms**: Add traversal strategies

## Configuration Management

All components are config-driven through `config.yaml`:

- Model selection
- Hyperparameters
- Evaluation settings
- Experimental configurations

This ensures reproducibility and easy experimentation.

## Testing Strategy

1. **Unit Tests**: Test each module independently
2. **Integration Tests**: Test module interactions
3. **End-to-End Tests**: Test complete workflows
4. **Performance Tests**: Benchmark scalability

## Future Enhancements

1. **Multi-modal Support**: Add figure and table processing
2. **Citation Integration**: Incorporate citation networks
3. **Real-time Updates**: Stream new papers
4. **Distributed Processing**: Scale to multiple machines
5. **Advanced Graph Algorithms**: PageRank, community detection

---

This architecture provides a solid foundation for research-grade RAG systems while maintaining clarity and extensibility.

