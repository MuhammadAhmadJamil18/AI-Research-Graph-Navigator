# ArXiv Integration Guide

## No Setup Required!

**Good News:** ArXiv integration is **completely automatic** and **free**. No API keys, no credentials, no registration needed!

## How It Works

The system uses the `arxiv` Python library which connects directly to ArXiv's public API. It's:
- ✅ **Free** - No cost
- ✅ **No API key** - Public access
- ✅ **No registration** - Works immediately
- ✅ **No limits** - Standard rate limits apply (very generous)

## Usage Examples

### Example 1: Basic Fetch (Default)

```python
from src.data_ingestion import ArXivIngester

# Create ingester
ingester = ArXivIngester()

# Fetch papers (default: AI/ML papers)
papers = ingester.fetch_papers(max_results=50)

# Save them
ingester.save_papers(papers)
```

### Example 2: Custom Query

```python
# Fetch specific category
papers = ingester.fetch_papers(
    query="cat:cs.AI",  # Only AI papers
    max_results=20
)

# Or search by keyword
papers = ingester.fetch_papers(
    query="transformer AND attention",
    max_results=30
)

# Or multiple categories
papers = ingester.fetch_papers(
    query="cat:cs.AI OR cat:cs.LG OR cat:cs.CL",
    max_results=50
)
```

### Example 3: In Streamlit App

The Streamlit app (`app.py`) has a built-in interface:
1. Open the app: `streamlit run app.py`
2. Use the sidebar to fetch papers
3. Adjust query and number of papers
4. Click "Fetch Papers from ArXiv"

## ArXiv Query Syntax

### Categories
- `cat:cs.AI` - Artificial Intelligence
- `cat:cs.LG` - Machine Learning
- `cat:cs.CL` - Computation and Language (NLP)
- `cat:cs.CV` - Computer Vision
- `cat:cs.NE` - Neural and Evolutionary Computing

### Operators
- `OR` - Either term
- `AND` - Both terms
- `NOT` - Exclude term
- `all:` - Search all fields

### Examples
```python
# AI or Machine Learning papers
query = "cat:cs.AI OR cat:cs.LG"

# Papers about transformers
query = "transformer"

# Recent papers in AI
query = "cat:cs.AI AND submittedDate:[20240101* TO 20241231*]"

# Exclude certain topics
query = "cat:cs.AI NOT quantum"
```

## What Gets Fetched

For each paper, the system automatically retrieves:
- ✅ **Title** - Paper title
- ✅ **Authors** - List of author names
- ✅ **Summary** - Abstract/description
- ✅ **Categories** - ArXiv categories (e.g., cs.AI)
- ✅ **Published Date** - When published
- ✅ **Updated Date** - Last update
- ✅ **PDF URL** - Link to PDF
- ✅ **Paper ID** - Unique identifier

## Data Storage

Fetched papers are saved to:
- **Location**: `data/papers.json`
- **Format**: JSON (human-readable)
- **Persistence**: Saved permanently (until you delete)

## Rate Limits

ArXiv API is very generous:
- ✅ **No daily limit** (for reasonable use)
- ✅ **3 requests per second** (automatic throttling)
- ✅ **No authentication needed**

## Troubleshooting

### Issue: "Connection Error"
**Solution**: Check internet connection. ArXiv API is public and should always be accessible.

### Issue: "No papers found"
**Solution**: 
- Try a broader query: `cat:cs.AI`
- Check query syntax
- Try without date filters

### Issue: "Timeout"
**Solution**: 
- Reduce `max_results` (try 10-20 first)
- Check internet speed
- Try again (ArXiv can be slow sometimes)

## Testing Connection

Test if ArXiv works:

```python
from src.data_ingestion import ArXivIngester

ingester = ArXivIngester()
papers = ingester.fetch_papers(max_results=5)  # Just 5 papers for test

if papers:
    print(f"✅ Success! Fetched {len(papers)} papers")
    print(f"First paper: {papers[0]['title']}")
else:
    print("❌ No papers fetched")
```

## Summary

**You don't need to "attach" or "connect" ArXiv - it's already built-in!**

Just use:
```python
from src.data_ingestion import ArXivIngester
ingester = ArXivIngester()
papers = ingester.fetch_papers()
```

That's it! 🎉

